﻿namespace toko_appdev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_utama = new System.Windows.Forms.Panel();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.DGV_category = new System.Windows.Forms.DataGridView();
            this.DGV_produk = new System.Windows.Forms.DataGridView();
            this.btn_removeC = new System.Windows.Forms.Button();
            this.btn_addC = new System.Windows.Forms.Button();
            this.tb_category = new System.Windows.Forms.TextBox();
            this.labelnama = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.cb_categoryP = new System.Windows.Forms.ComboBox();
            this.btn_editP = new System.Windows.Forms.Button();
            this.btn_removeP = new System.Windows.Forms.Button();
            this.btn_addP = new System.Windows.Forms.Button();
            this.tb_stockP = new System.Windows.Forms.TextBox();
            this.labelstockp = new System.Windows.Forms.Label();
            this.tb_hargaP = new System.Windows.Forms.TextBox();
            this.labelhargap = new System.Windows.Forms.Label();
            this.labelcategoryp = new System.Windows.Forms.Label();
            this.tb_namaP = new System.Windows.Forms.TextBox();
            this.labelnamap = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelProduk = new System.Windows.Forms.Label();
            this.panel_utama.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_produk)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_utama
            // 
            this.panel_utama.AutoSize = true;
            this.panel_utama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel_utama.Controls.Add(this.btn_all);
            this.panel_utama.Controls.Add(this.btn_filter);
            this.panel_utama.Controls.Add(this.cb_filter);
            this.panel_utama.Controls.Add(this.DGV_category);
            this.panel_utama.Controls.Add(this.DGV_produk);
            this.panel_utama.Controls.Add(this.btn_removeC);
            this.panel_utama.Controls.Add(this.btn_addC);
            this.panel_utama.Controls.Add(this.tb_category);
            this.panel_utama.Controls.Add(this.labelnama);
            this.panel_utama.Controls.Add(this.labelCategory);
            this.panel_utama.Controls.Add(this.cb_categoryP);
            this.panel_utama.Controls.Add(this.btn_editP);
            this.panel_utama.Controls.Add(this.btn_removeP);
            this.panel_utama.Controls.Add(this.btn_addP);
            this.panel_utama.Controls.Add(this.tb_stockP);
            this.panel_utama.Controls.Add(this.labelstockp);
            this.panel_utama.Controls.Add(this.tb_hargaP);
            this.panel_utama.Controls.Add(this.labelhargap);
            this.panel_utama.Controls.Add(this.labelcategoryp);
            this.panel_utama.Controls.Add(this.tb_namaP);
            this.panel_utama.Controls.Add(this.labelnamap);
            this.panel_utama.Controls.Add(this.label2);
            this.panel_utama.Controls.Add(this.labelProduk);
            this.panel_utama.Location = new System.Drawing.Point(12, 16);
            this.panel_utama.Name = "panel_utama";
            this.panel_utama.Size = new System.Drawing.Size(1122, 602);
            this.panel_utama.TabIndex = 0;
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(503, 19);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(44, 25);
            this.btn_all.TabIndex = 27;
            this.btn_all.Text = "all";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(553, 19);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(55, 25);
            this.btn_filter.TabIndex = 26;
            this.btn_filter.Text = "filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(614, 19);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(129, 24);
            this.cb_filter.TabIndex = 24;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // DGV_category
            // 
            this.DGV_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_category.Location = new System.Drawing.Point(776, 52);
            this.DGV_category.Name = "DGV_category";
            this.DGV_category.RowHeadersWidth = 51;
            this.DGV_category.RowTemplate.Height = 24;
            this.DGV_category.Size = new System.Drawing.Size(340, 304);
            this.DGV_category.TabIndex = 23;
            // 
            // DGV_produk
            // 
            this.DGV_produk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_produk.Location = new System.Drawing.Point(3, 52);
            this.DGV_produk.Name = "DGV_produk";
            this.DGV_produk.RowHeadersWidth = 51;
            this.DGV_produk.RowTemplate.Height = 24;
            this.DGV_produk.Size = new System.Drawing.Size(740, 375);
            this.DGV_produk.TabIndex = 22;
            this.DGV_produk.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_produk_CellClick);
            // 
            // btn_removeC
            // 
            this.btn_removeC.Location = new System.Drawing.Point(932, 390);
            this.btn_removeC.Name = "btn_removeC";
            this.btn_removeC.Size = new System.Drawing.Size(81, 50);
            this.btn_removeC.TabIndex = 21;
            this.btn_removeC.Text = "remove category";
            this.btn_removeC.UseVisualStyleBackColor = true;
            this.btn_removeC.Click += new System.EventHandler(this.btn_removeC_Click);
            // 
            // btn_addC
            // 
            this.btn_addC.Location = new System.Drawing.Point(842, 390);
            this.btn_addC.Name = "btn_addC";
            this.btn_addC.Size = new System.Drawing.Size(84, 50);
            this.btn_addC.TabIndex = 20;
            this.btn_addC.Text = "add category";
            this.btn_addC.UseVisualStyleBackColor = true;
            this.btn_addC.Click += new System.EventHandler(this.btn_addC_Click);
            // 
            // tb_category
            // 
            this.tb_category.Location = new System.Drawing.Point(842, 362);
            this.tb_category.Name = "tb_category";
            this.tb_category.Size = new System.Drawing.Size(186, 22);
            this.tb_category.TabIndex = 19;
            // 
            // labelnama
            // 
            this.labelnama.AutoSize = true;
            this.labelnama.Location = new System.Drawing.Point(783, 362);
            this.labelnama.Name = "labelnama";
            this.labelnama.Size = new System.Drawing.Size(41, 16);
            this.labelnama.TabIndex = 18;
            this.labelnama.Text = "nama";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory.Location = new System.Drawing.Point(772, 26);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(102, 24);
            this.labelCategory.TabIndex = 17;
            this.labelCategory.Text = "CATEGORY";
            // 
            // cb_categoryP
            // 
            this.cb_categoryP.FormattingEnabled = true;
            this.cb_categoryP.Location = new System.Drawing.Point(74, 508);
            this.cb_categoryP.Name = "cb_categoryP";
            this.cb_categoryP.Size = new System.Drawing.Size(126, 24);
            this.cb_categoryP.TabIndex = 16;
            // 
            // btn_editP
            // 
            this.btn_editP.Location = new System.Drawing.Point(283, 508);
            this.btn_editP.Name = "btn_editP";
            this.btn_editP.Size = new System.Drawing.Size(73, 50);
            this.btn_editP.TabIndex = 14;
            this.btn_editP.Text = "edit product";
            this.btn_editP.UseVisualStyleBackColor = true;
            this.btn_editP.Click += new System.EventHandler(this.btn_editP_Click);
            // 
            // btn_removeP
            // 
            this.btn_removeP.Location = new System.Drawing.Point(362, 508);
            this.btn_removeP.Name = "btn_removeP";
            this.btn_removeP.Size = new System.Drawing.Size(71, 50);
            this.btn_removeP.TabIndex = 13;
            this.btn_removeP.Text = "remove product";
            this.btn_removeP.UseVisualStyleBackColor = true;
            this.btn_removeP.Click += new System.EventHandler(this.btn_removeP_Click);
            // 
            // btn_addP
            // 
            this.btn_addP.Location = new System.Drawing.Point(206, 508);
            this.btn_addP.Name = "btn_addP";
            this.btn_addP.Size = new System.Drawing.Size(71, 50);
            this.btn_addP.TabIndex = 12;
            this.btn_addP.Text = "add product";
            this.btn_addP.UseVisualStyleBackColor = true;
            this.btn_addP.Click += new System.EventHandler(this.btn_addP_Click);
            // 
            // tb_stockP
            // 
            this.tb_stockP.Location = new System.Drawing.Point(74, 564);
            this.tb_stockP.Name = "tb_stockP";
            this.tb_stockP.Size = new System.Drawing.Size(126, 22);
            this.tb_stockP.TabIndex = 11;
            this.tb_stockP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stockP_KeyPress);
            // 
            // labelstockp
            // 
            this.labelstockp.AutoSize = true;
            this.labelstockp.Location = new System.Drawing.Point(15, 564);
            this.labelstockp.Name = "labelstockp";
            this.labelstockp.Size = new System.Drawing.Size(39, 16);
            this.labelstockp.TabIndex = 10;
            this.labelstockp.Text = "stock";
            // 
            // tb_hargaP
            // 
            this.tb_hargaP.Location = new System.Drawing.Point(74, 536);
            this.tb_hargaP.Name = "tb_hargaP";
            this.tb_hargaP.Size = new System.Drawing.Size(126, 22);
            this.tb_hargaP.TabIndex = 9;
            this.tb_hargaP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaP_KeyPress);
            // 
            // labelhargap
            // 
            this.labelhargap.AutoSize = true;
            this.labelhargap.Location = new System.Drawing.Point(15, 536);
            this.labelhargap.Name = "labelhargap";
            this.labelhargap.Size = new System.Drawing.Size(42, 16);
            this.labelhargap.TabIndex = 8;
            this.labelhargap.Text = "harga";
            // 
            // labelcategoryp
            // 
            this.labelcategoryp.AutoSize = true;
            this.labelcategoryp.Location = new System.Drawing.Point(15, 508);
            this.labelcategoryp.Name = "labelcategoryp";
            this.labelcategoryp.Size = new System.Drawing.Size(60, 16);
            this.labelcategoryp.TabIndex = 6;
            this.labelcategoryp.Text = "category";
            // 
            // tb_namaP
            // 
            this.tb_namaP.Location = new System.Drawing.Point(74, 480);
            this.tb_namaP.Name = "tb_namaP";
            this.tb_namaP.Size = new System.Drawing.Size(359, 22);
            this.tb_namaP.TabIndex = 3;
            // 
            // labelnamap
            // 
            this.labelnamap.AutoSize = true;
            this.labelnamap.Location = new System.Drawing.Point(15, 480);
            this.labelnamap.Name = "labelnamap";
            this.labelnamap.Size = new System.Drawing.Size(41, 16);
            this.labelnamap.TabIndex = 2;
            this.labelnamap.Text = "nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 436);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "DETAIL";
            // 
            // labelProduk
            // 
            this.labelProduk.AutoSize = true;
            this.labelProduk.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProduk.Location = new System.Drawing.Point(34, 19);
            this.labelProduk.Name = "labelProduk";
            this.labelProduk.Size = new System.Drawing.Size(82, 24);
            this.labelProduk.TabIndex = 0;
            this.labelProduk.Text = "PRODUK";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1140, 630);
            this.Controls.Add(this.panel_utama);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_utama.ResumeLayout(false);
            this.panel_utama.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_produk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_utama;
        private System.Windows.Forms.Label labelProduk;
        private System.Windows.Forms.TextBox tb_stockP;
        private System.Windows.Forms.Label labelstockp;
        private System.Windows.Forms.TextBox tb_hargaP;
        private System.Windows.Forms.Label labelhargap;
        private System.Windows.Forms.Label labelcategoryp;
        private System.Windows.Forms.TextBox tb_namaP;
        private System.Windows.Forms.Label labelnamap;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_addP;
        private System.Windows.Forms.Button btn_removeC;
        private System.Windows.Forms.Button btn_addC;
        private System.Windows.Forms.TextBox tb_category;
        private System.Windows.Forms.Label labelnama;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.ComboBox cb_categoryP;
        private System.Windows.Forms.Button btn_editP;
        private System.Windows.Forms.Button btn_removeP;
        private System.Windows.Forms.DataGridView DGV_produk;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.DataGridView DGV_category;
        private System.Windows.Forms.Button btn_all;
    }
}

