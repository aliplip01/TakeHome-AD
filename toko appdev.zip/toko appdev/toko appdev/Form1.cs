﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace toko_appdev
{
    public partial class Form1 : Form
    {
        DataTable dtpsimpan;  //nyimpen data produk
        DataTable dtptampil;  //nampilkan data produk
        DataTable dtcategory; //nyimpan data category
        int i_category = 5;
        int editrows;
        public Form1()
        {
            InitializeComponent();

            //datatable produk simpan
            dtpsimpan = new DataTable();
            dtpsimpan.Columns.Add("ID Produk");
            dtpsimpan.Columns.Add("Nama Produk");
            dtpsimpan.Columns.Add("Harga");
            dtpsimpan.Columns.Add("Stock");
            dtpsimpan.Columns.Add("ID Category");

            //datatable Category
            dtcategory = new DataTable();
            DGV_category.DataSource = dtcategory;
            dtcategory.Columns.Add("ID Category");
            dtcategory.Columns.Add("Nama Category");
            dtcategory.Rows.Add("C1", "Jas");
            dtcategory.Rows.Add("C2", "T-Shirt");
            dtcategory.Rows.Add("C3", "Rok");
            dtcategory.Rows.Add("C4", "Celana");
            dtcategory.Rows.Add("C5", "Cawat");

            cb_filter.Items.Add("C1");
            cb_filter.Items.Add("C2");
            cb_filter.Items.Add("C3");
            cb_filter.Items.Add("C4");
            cb_filter.Items.Add("C5");

            cb_categoryP.Items.Add("C1");
            cb_categoryP.Items.Add("C2");
            cb_categoryP.Items.Add("C3");
            cb_categoryP.Items.Add("C4");
            cb_categoryP.Items.Add("C5");


            //datatable produk tampilkan
            dtptampil = new DataTable();
            dtptampil = dtpsimpan;
            DGV_produk.DataSource = dtptampil;
            dtpsimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtpsimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtpsimpan.Rows.Add("T002", "T-Shirt Obsesive", "75000", "16", "C2");
            dtpsimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtpsimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtpsimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtpsimpan.Rows.Add("C002", "Celana Blink-Blink", "1000000", "1", "C5");
            dtpsimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
        }
        //DUA BUTTON FILTER
        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            DGV_produk.DataSource = dtptampil;
            cb_filter.SelectedItem = null;
        }
        private void btn_filter_Click(object sender, EventArgs e)
        { 
            cb_filter.Enabled = true;
            DGV_produk.DataSource = dtptampil;
        }
        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = cb_filter.SelectedItem.ToString();
            DataTable filteredTable = dtpsimpan.Clone(); // Clone struktur tabel tanpa data

            for (int i = 0; i < dtpsimpan.Rows.Count; i++)
            {
                if (dtpsimpan.Rows[i][4].ToString() == filter)
                {
                    DataRow simpen = filteredTable.NewRow();
                    simpen.ItemArray = dtpsimpan.Rows[i].ItemArray;
                    filteredTable.Rows.Add(simpen);
                }
            }
            DGV_produk.DataSource = filteredTable;
        }
        private void btn_addP_Click(object sender, EventArgs e)
        {
            cek();
            bool produkDitemukan = false;

            for (int i = 0; i < dtpsimpan.Rows.Count; i++)
            {
                if (dtpsimpan.Rows[i]["Nama Produk"].Equals(tb_namaP.Text) &&
                    dtpsimpan.Rows[i]["ID Category"].Equals(cb_categoryP.SelectedItem))
                {
                    int stok = Convert.ToInt32(dtpsimpan.Rows[i]["Stock"]) + Convert.ToInt32(tb_stockP.Text);
                    dtpsimpan.Rows[i]["Stock"] = stok.ToString();
                    dtptampil = dtpsimpan;
                    produkDitemukan = true;
                    DGV_produk.ClearSelection();
                    tb_namaP.Clear();
                    tb_stockP.Clear();
                    tb_hargaP.Clear();
                    cb_categoryP.SelectedItem = null;
                    break; // Keluar dari loop setelah menambahkan stok
                }
            }

            if (!produkDitemukan)
            {
                string hurufAwal = tb_namaP.Text.Substring(0, 1);
                string idProduk = "";
                int nomorUrutTerakhir = 0;

                // Mencari nomor urut terakhir untuk huruf awal yang sama
                for (int i = 0; i < dtpsimpan.Rows.Count; i++)
                {
                    if (dtpsimpan.Rows[i]["ID Produk"].ToString().StartsWith(hurufAwal))
                    {
                        int nomorUrut;
                        if (int.TryParse(dtpsimpan.Rows[i]["ID Produk"].ToString().Substring(1), out nomorUrut))
                        {
                            if (nomorUrut > nomorUrutTerakhir)
                            {
                                nomorUrutTerakhir = nomorUrut;
                            }
                        }
                    }
                }

                // Menambahkan 1 untuk mendapatkan nomor urut yang unik
                nomorUrutTerakhir++;

                // Membuat ID produk dengan format yang diinginkan
                idProduk = $"{hurufAwal}{nomorUrutTerakhir:000}";

                // Menambahkan produk baru ke dalam DataTable
                dtpsimpan.Rows.Add(idProduk, tb_namaP.Text, tb_hargaP.Text, tb_stockP.Text, cb_categoryP.SelectedItem);
                dtptampil = dtpsimpan;
                tb_namaP.Clear();
                tb_stockP.Clear();
                tb_hargaP.Clear();
                cb_categoryP.SelectedItem = null;
            }
        }
        private void btn_editP_Click(object sender, EventArgs e)
        {
            cek();
            dtpsimpan.Rows[editrows]["Nama Produk"] = tb_namaP.Text;
            dtpsimpan.Rows[editrows]["Harga"] = tb_hargaP.Text;
            dtpsimpan.Rows[editrows]["Stock"] = tb_stockP.Text;
            dtpsimpan.Rows[editrows]["ID Category"] = cb_categoryP.SelectedItem;

            if (dtpsimpan.Rows[editrows]["Stock"].Equals("0"))
            {
                dtpsimpan.Rows[editrows].Delete();
            }
            tb_namaP.Clear();
            tb_hargaP.Clear();
            tb_stockP.Clear();
            cb_categoryP.SelectedItem = null;
            DGV_produk.ClearSelection();
        }
        private void btn_removeP_Click(object sender, EventArgs e)
        {
            cek();
            dtpsimpan.Rows[editrows].Delete();
            tb_namaP.Clear();
            tb_stockP.Clear();
            tb_hargaP.Clear();
            cb_categoryP.SelectedItem = null;
        }
        private void cek()
        { 
            if (tb_namaP.Text == "")
            {
                MessageBox.Show("blm diisi");
            }
            else if (cb_categoryP.SelectedItem == null)
            {
                MessageBox.Show("blm diisi");
            }
            else if (tb_hargaP.Text == "")
            {
                MessageBox.Show("blm diisi");
            }
            else if (tb_stockP.Text == "")
            {
                MessageBox.Show("blm diisi");
            }
        }
        //CATEGORY CATEGORY CATEGORY
        private void btn_addC_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i < dtcategory.Rows.Count; i++)
            {
                if (dtcategory.Rows[i][1].ToString() == tb_category.Text)
                {
                    MessageBox.Show("Category sudah ada");
                    x++;
                    break;
                }
                else if (tb_category.Text == "")
                {
                    MessageBox.Show("blm diisi");
                    x++;
                    break;
                }
            }
            if (x == 0)
            {
                i_category++;
                dtcategory.Rows.Add($"C{i_category}", $"{tb_category.Text}");
                cb_filter.Items.Add($"C{i_category}");
                cb_categoryP.Items.Add($"C{i_category}");

                tb_category.Clear();
            }
        }
        private void btn_removeC_Click(object sender, EventArgs e)
        {
            //remove DGV_produk
            string IDC = bantuan();
            cb_categoryP.Items.Remove( IDC );

            int x = 0;
            for (int i = dtpsimpan.Rows.Count - 1; i >= 0; i--)
            {
                if (dtpsimpan.Rows[i][4].ToString() == IDC)
                {
                    dtpsimpan.Rows.RemoveAt(i);
                    x++;
                }
                else if (tb_category.Text == "")
                {
                    MessageBox.Show("blm diisi");
                    x++;
                    break;
                }
            }
            dtptampil = dtpsimpan;
            //remove DGV_category
            for(int i = dtcategory.Rows.Count - 1; i >= 0; i--)
            {
                if (dtcategory.Rows[i][1].ToString() == tb_category.Text)
                {
                    dtcategory.Rows.RemoveAt(i);
                    x++;
                }
            }
            if (x == 0)
            {
                MessageBox.Show("Category tidak ditemukan");
                tb_category.Clear();
            }
            tb_category.Clear();
        }
        private string bantuan()
        {
            string IDC = "";
            for (int i = 0; i < dtcategory.Rows.Count; i++)
            {
                if (dtcategory.Rows[i][1].ToString() == tb_category.Text)
                {
                    IDC = dtcategory.Rows[i][0].ToString();
                    break; 
                }
            }
            return IDC;
        }
        private void tb_hargaP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Hanya angka yang diperbolehkan!");
                e.Handled = true; // Mencegah karakter dimasukkan ke TextBox
            }
        }

        private void tb_stockP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Hanya angka yang diperbolehkan!");
                e.Handled = true; // Mencegah karakter dimasukkan ke TextBox
            }
        }
        private void DGV_produk_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedRow = DGV_produk.Rows[e.RowIndex];
            tb_namaP.Text = selectedRow.Cells["Nama Produk"].Value.ToString();
            tb_hargaP.Text = selectedRow.Cells["Harga"].Value.ToString();
            tb_stockP.Text = selectedRow.Cells["Stock"].Value.ToString();
            cb_categoryP.SelectedItem = selectedRow.Cells["ID Category"].Value.ToString();

            for (int i = 0; i < dtpsimpan.Rows.Count; i++)
            {
                if (dtpsimpan.Rows[i][1].Equals(tb_namaP.Text))
                {
                    editrows = i;
                    break;    
                }
            }
        }
    }
}