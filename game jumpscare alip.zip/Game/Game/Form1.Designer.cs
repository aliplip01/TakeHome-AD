﻿namespace Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.huruf_Q = new System.Windows.Forms.Button();
            this.huruf_W = new System.Windows.Forms.Button();
            this.huruf_E = new System.Windows.Forms.Button();
            this.huruf_R = new System.Windows.Forms.Button();
            this.huruf_T = new System.Windows.Forms.Button();
            this.huruf_Y = new System.Windows.Forms.Button();
            this.huruf_U = new System.Windows.Forms.Button();
            this.huruf_I = new System.Windows.Forms.Button();
            this.huruf_O = new System.Windows.Forms.Button();
            this.huruf_P = new System.Windows.Forms.Button();
            this.huruf_L = new System.Windows.Forms.Button();
            this.huruf_K = new System.Windows.Forms.Button();
            this.huruf_J = new System.Windows.Forms.Button();
            this.huruf_H = new System.Windows.Forms.Button();
            this.huruf_G = new System.Windows.Forms.Button();
            this.huruf_F = new System.Windows.Forms.Button();
            this.huruf_D = new System.Windows.Forms.Button();
            this.huruf_S = new System.Windows.Forms.Button();
            this.huruf_A = new System.Windows.Forms.Button();
            this.huruf_M = new System.Windows.Forms.Button();
            this.huruf_N = new System.Windows.Forms.Button();
            this.huruf_B = new System.Windows.Forms.Button();
            this.huruf_V = new System.Windows.Forms.Button();
            this.huruf_C = new System.Windows.Forms.Button();
            this.huruf_X = new System.Windows.Forms.Button();
            this.huruf_Z = new System.Windows.Forms.Button();
            this.kata_kedua = new System.Windows.Forms.Label();
            this.kata_keempat = new System.Windows.Forms.Label();
            this.kata_ketiga = new System.Windows.Forms.Label();
            this.kata_pertama = new System.Windows.Forms.Label();
            this.kata_kelima = new System.Windows.Forms.Label();
            this.panel_PlayGame = new System.Windows.Forms.Panel();
            this.panel_Utama = new System.Windows.Forms.Panel();
            this.play_btn = new System.Windows.Forms.TextBox();
            this.kata_2 = new System.Windows.Forms.TextBox();
            this.kata_3 = new System.Windows.Forms.TextBox();
            this.kata_5 = new System.Windows.Forms.TextBox();
            this.kata_4 = new System.Windows.Forms.TextBox();
            this.kata_1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_win = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_PlayGame.SuspendLayout();
            this.panel_Utama.SuspendLayout();
            this.panel_win.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // huruf_Q
            // 
            this.huruf_Q.Location = new System.Drawing.Point(37, 176);
            this.huruf_Q.Name = "huruf_Q";
            this.huruf_Q.Size = new System.Drawing.Size(72, 63);
            this.huruf_Q.TabIndex = 0;
            this.huruf_Q.Text = "Q";
            this.huruf_Q.UseVisualStyleBackColor = true;
            this.huruf_Q.Click += new System.EventHandler(this.huruf_Q_Click);
            // 
            // huruf_W
            // 
            this.huruf_W.Location = new System.Drawing.Point(115, 176);
            this.huruf_W.Name = "huruf_W";
            this.huruf_W.Size = new System.Drawing.Size(72, 63);
            this.huruf_W.TabIndex = 1;
            this.huruf_W.Text = "W";
            this.huruf_W.UseVisualStyleBackColor = true;
            this.huruf_W.Click += new System.EventHandler(this.huruf_W_Click);
            // 
            // huruf_E
            // 
            this.huruf_E.Location = new System.Drawing.Point(193, 176);
            this.huruf_E.Name = "huruf_E";
            this.huruf_E.Size = new System.Drawing.Size(72, 63);
            this.huruf_E.TabIndex = 2;
            this.huruf_E.Text = "E";
            this.huruf_E.UseVisualStyleBackColor = true;
            this.huruf_E.Click += new System.EventHandler(this.huruf_E_Click);
            // 
            // huruf_R
            // 
            this.huruf_R.Location = new System.Drawing.Point(271, 176);
            this.huruf_R.Name = "huruf_R";
            this.huruf_R.Size = new System.Drawing.Size(72, 63);
            this.huruf_R.TabIndex = 3;
            this.huruf_R.Text = "R";
            this.huruf_R.UseVisualStyleBackColor = true;
            this.huruf_R.Click += new System.EventHandler(this.huruf_R_Click);
            // 
            // huruf_T
            // 
            this.huruf_T.Location = new System.Drawing.Point(349, 176);
            this.huruf_T.Name = "huruf_T";
            this.huruf_T.Size = new System.Drawing.Size(72, 63);
            this.huruf_T.TabIndex = 4;
            this.huruf_T.Text = "T";
            this.huruf_T.UseVisualStyleBackColor = true;
            this.huruf_T.Click += new System.EventHandler(this.huruf_T_Click);
            // 
            // huruf_Y
            // 
            this.huruf_Y.Location = new System.Drawing.Point(427, 176);
            this.huruf_Y.Name = "huruf_Y";
            this.huruf_Y.Size = new System.Drawing.Size(72, 63);
            this.huruf_Y.TabIndex = 5;
            this.huruf_Y.Text = "Y";
            this.huruf_Y.UseVisualStyleBackColor = true;
            this.huruf_Y.Click += new System.EventHandler(this.huruf_Y_Click);
            // 
            // huruf_U
            // 
            this.huruf_U.Location = new System.Drawing.Point(505, 176);
            this.huruf_U.Name = "huruf_U";
            this.huruf_U.Size = new System.Drawing.Size(72, 63);
            this.huruf_U.TabIndex = 6;
            this.huruf_U.Text = "U";
            this.huruf_U.UseVisualStyleBackColor = true;
            this.huruf_U.Click += new System.EventHandler(this.huruf_U_Click);
            // 
            // huruf_I
            // 
            this.huruf_I.Location = new System.Drawing.Point(583, 176);
            this.huruf_I.Name = "huruf_I";
            this.huruf_I.Size = new System.Drawing.Size(72, 63);
            this.huruf_I.TabIndex = 7;
            this.huruf_I.Text = "I";
            this.huruf_I.UseVisualStyleBackColor = true;
            this.huruf_I.Click += new System.EventHandler(this.huruf_I_Click);
            // 
            // huruf_O
            // 
            this.huruf_O.Location = new System.Drawing.Point(661, 176);
            this.huruf_O.Name = "huruf_O";
            this.huruf_O.Size = new System.Drawing.Size(72, 63);
            this.huruf_O.TabIndex = 8;
            this.huruf_O.Text = "O";
            this.huruf_O.UseVisualStyleBackColor = true;
            this.huruf_O.Click += new System.EventHandler(this.huruf_O_Click);
            // 
            // huruf_P
            // 
            this.huruf_P.Location = new System.Drawing.Point(739, 176);
            this.huruf_P.Name = "huruf_P";
            this.huruf_P.Size = new System.Drawing.Size(72, 63);
            this.huruf_P.TabIndex = 9;
            this.huruf_P.Text = "P";
            this.huruf_P.UseVisualStyleBackColor = true;
            this.huruf_P.Click += new System.EventHandler(this.huruf_P_Click);
            // 
            // huruf_L
            // 
            this.huruf_L.Location = new System.Drawing.Point(705, 262);
            this.huruf_L.Name = "huruf_L";
            this.huruf_L.Size = new System.Drawing.Size(72, 63);
            this.huruf_L.TabIndex = 18;
            this.huruf_L.Text = "L";
            this.huruf_L.UseVisualStyleBackColor = true;
            this.huruf_L.Click += new System.EventHandler(this.huruf_L_Click);
            // 
            // huruf_K
            // 
            this.huruf_K.Location = new System.Drawing.Point(627, 262);
            this.huruf_K.Name = "huruf_K";
            this.huruf_K.Size = new System.Drawing.Size(72, 63);
            this.huruf_K.TabIndex = 17;
            this.huruf_K.Text = "K";
            this.huruf_K.UseVisualStyleBackColor = true;
            this.huruf_K.Click += new System.EventHandler(this.huruf_K_Click);
            // 
            // huruf_J
            // 
            this.huruf_J.Location = new System.Drawing.Point(549, 262);
            this.huruf_J.Name = "huruf_J";
            this.huruf_J.Size = new System.Drawing.Size(72, 63);
            this.huruf_J.TabIndex = 16;
            this.huruf_J.Text = "J";
            this.huruf_J.UseVisualStyleBackColor = true;
            this.huruf_J.Click += new System.EventHandler(this.huruf_J_Click);
            // 
            // huruf_H
            // 
            this.huruf_H.Location = new System.Drawing.Point(471, 262);
            this.huruf_H.Name = "huruf_H";
            this.huruf_H.Size = new System.Drawing.Size(72, 63);
            this.huruf_H.TabIndex = 15;
            this.huruf_H.Text = "H";
            this.huruf_H.UseVisualStyleBackColor = true;
            this.huruf_H.Click += new System.EventHandler(this.huruf_H_Click);
            // 
            // huruf_G
            // 
            this.huruf_G.Location = new System.Drawing.Point(393, 262);
            this.huruf_G.Name = "huruf_G";
            this.huruf_G.Size = new System.Drawing.Size(72, 63);
            this.huruf_G.TabIndex = 14;
            this.huruf_G.Text = "G";
            this.huruf_G.UseVisualStyleBackColor = true;
            this.huruf_G.Click += new System.EventHandler(this.huruf_G_Click);
            // 
            // huruf_F
            // 
            this.huruf_F.Location = new System.Drawing.Point(315, 262);
            this.huruf_F.Name = "huruf_F";
            this.huruf_F.Size = new System.Drawing.Size(72, 63);
            this.huruf_F.TabIndex = 13;
            this.huruf_F.Text = "F";
            this.huruf_F.UseVisualStyleBackColor = true;
            this.huruf_F.Click += new System.EventHandler(this.huruf_F_Click);
            // 
            // huruf_D
            // 
            this.huruf_D.Location = new System.Drawing.Point(237, 262);
            this.huruf_D.Name = "huruf_D";
            this.huruf_D.Size = new System.Drawing.Size(72, 63);
            this.huruf_D.TabIndex = 12;
            this.huruf_D.Text = "D";
            this.huruf_D.UseVisualStyleBackColor = true;
            this.huruf_D.Click += new System.EventHandler(this.huruf_D_Click);
            // 
            // huruf_S
            // 
            this.huruf_S.Location = new System.Drawing.Point(159, 262);
            this.huruf_S.Name = "huruf_S";
            this.huruf_S.Size = new System.Drawing.Size(72, 63);
            this.huruf_S.TabIndex = 11;
            this.huruf_S.Text = "S";
            this.huruf_S.UseVisualStyleBackColor = true;
            this.huruf_S.Click += new System.EventHandler(this.huruf_S_Click);
            // 
            // huruf_A
            // 
            this.huruf_A.Location = new System.Drawing.Point(81, 262);
            this.huruf_A.Name = "huruf_A";
            this.huruf_A.Size = new System.Drawing.Size(72, 63);
            this.huruf_A.TabIndex = 10;
            this.huruf_A.Text = "A";
            this.huruf_A.UseVisualStyleBackColor = true;
            this.huruf_A.Click += new System.EventHandler(this.huruf_A_Click);
            // 
            // huruf_M
            // 
            this.huruf_M.Location = new System.Drawing.Point(627, 348);
            this.huruf_M.Name = "huruf_M";
            this.huruf_M.Size = new System.Drawing.Size(72, 63);
            this.huruf_M.TabIndex = 25;
            this.huruf_M.Text = "M";
            this.huruf_M.UseVisualStyleBackColor = true;
            this.huruf_M.Click += new System.EventHandler(this.huruf_M_Click);
            // 
            // huruf_N
            // 
            this.huruf_N.Location = new System.Drawing.Point(549, 348);
            this.huruf_N.Name = "huruf_N";
            this.huruf_N.Size = new System.Drawing.Size(72, 63);
            this.huruf_N.TabIndex = 24;
            this.huruf_N.Text = "N";
            this.huruf_N.UseVisualStyleBackColor = true;
            this.huruf_N.Click += new System.EventHandler(this.huruf_N_Click);
            // 
            // huruf_B
            // 
            this.huruf_B.Location = new System.Drawing.Point(471, 348);
            this.huruf_B.Name = "huruf_B";
            this.huruf_B.Size = new System.Drawing.Size(72, 63);
            this.huruf_B.TabIndex = 23;
            this.huruf_B.Text = "B";
            this.huruf_B.UseVisualStyleBackColor = true;
            this.huruf_B.Click += new System.EventHandler(this.huruf_B_Click);
            // 
            // huruf_V
            // 
            this.huruf_V.Location = new System.Drawing.Point(393, 348);
            this.huruf_V.Name = "huruf_V";
            this.huruf_V.Size = new System.Drawing.Size(72, 63);
            this.huruf_V.TabIndex = 22;
            this.huruf_V.Text = "V";
            this.huruf_V.UseVisualStyleBackColor = true;
            this.huruf_V.Click += new System.EventHandler(this.huruf_V_Click);
            // 
            // huruf_C
            // 
            this.huruf_C.Location = new System.Drawing.Point(315, 348);
            this.huruf_C.Name = "huruf_C";
            this.huruf_C.Size = new System.Drawing.Size(72, 63);
            this.huruf_C.TabIndex = 21;
            this.huruf_C.Text = "C";
            this.huruf_C.UseVisualStyleBackColor = true;
            this.huruf_C.Click += new System.EventHandler(this.huruf_C_Click);
            // 
            // huruf_X
            // 
            this.huruf_X.Location = new System.Drawing.Point(237, 348);
            this.huruf_X.Name = "huruf_X";
            this.huruf_X.Size = new System.Drawing.Size(72, 63);
            this.huruf_X.TabIndex = 20;
            this.huruf_X.Text = "X";
            this.huruf_X.UseVisualStyleBackColor = true;
            this.huruf_X.Click += new System.EventHandler(this.huruf_X_Click);
            // 
            // huruf_Z
            // 
            this.huruf_Z.Location = new System.Drawing.Point(159, 348);
            this.huruf_Z.Name = "huruf_Z";
            this.huruf_Z.Size = new System.Drawing.Size(72, 63);
            this.huruf_Z.TabIndex = 19;
            this.huruf_Z.Text = "Z";
            this.huruf_Z.UseVisualStyleBackColor = true;
            this.huruf_Z.Click += new System.EventHandler(this.huruf_Z_Click);
            // 
            // kata_kedua
            // 
            this.kata_kedua.AutoSize = true;
            this.kata_kedua.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_kedua.Location = new System.Drawing.Point(307, 71);
            this.kata_kedua.Name = "kata_kedua";
            this.kata_kedua.Size = new System.Drawing.Size(60, 48);
            this.kata_kedua.TabIndex = 28;
            this.kata_kedua.Text = "_";
            // 
            // kata_keempat
            // 
            this.kata_keempat.AutoSize = true;
            this.kata_keempat.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_keempat.Location = new System.Drawing.Point(483, 71);
            this.kata_keempat.Name = "kata_keempat";
            this.kata_keempat.Size = new System.Drawing.Size(60, 48);
            this.kata_keempat.TabIndex = 29;
            this.kata_keempat.Text = "_";
            // 
            // kata_ketiga
            // 
            this.kata_ketiga.AutoSize = true;
            this.kata_ketiga.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_ketiga.Location = new System.Drawing.Point(394, 71);
            this.kata_ketiga.Name = "kata_ketiga";
            this.kata_ketiga.Size = new System.Drawing.Size(60, 48);
            this.kata_ketiga.TabIndex = 30;
            this.kata_ketiga.Text = "_";
            // 
            // kata_pertama
            // 
            this.kata_pertama.AutoSize = true;
            this.kata_pertama.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_pertama.Location = new System.Drawing.Point(205, 71);
            this.kata_pertama.Name = "kata_pertama";
            this.kata_pertama.Size = new System.Drawing.Size(60, 48);
            this.kata_pertama.TabIndex = 31;
            this.kata_pertama.Text = "_";
            // 
            // kata_kelima
            // 
            this.kata_kelima.AutoSize = true;
            this.kata_kelima.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_kelima.Location = new System.Drawing.Point(575, 71);
            this.kata_kelima.Name = "kata_kelima";
            this.kata_kelima.Size = new System.Drawing.Size(60, 48);
            this.kata_kelima.TabIndex = 32;
            this.kata_kelima.Text = "_";
            // 
            // panel_PlayGame
            // 
            this.panel_PlayGame.Controls.Add(this.kata_kelima);
            this.panel_PlayGame.Controls.Add(this.kata_pertama);
            this.panel_PlayGame.Controls.Add(this.kata_ketiga);
            this.panel_PlayGame.Controls.Add(this.kata_keempat);
            this.panel_PlayGame.Controls.Add(this.kata_kedua);
            this.panel_PlayGame.Controls.Add(this.huruf_M);
            this.panel_PlayGame.Controls.Add(this.huruf_N);
            this.panel_PlayGame.Controls.Add(this.huruf_B);
            this.panel_PlayGame.Controls.Add(this.huruf_V);
            this.panel_PlayGame.Controls.Add(this.huruf_C);
            this.panel_PlayGame.Controls.Add(this.huruf_X);
            this.panel_PlayGame.Controls.Add(this.huruf_Z);
            this.panel_PlayGame.Controls.Add(this.huruf_L);
            this.panel_PlayGame.Controls.Add(this.huruf_K);
            this.panel_PlayGame.Controls.Add(this.huruf_J);
            this.panel_PlayGame.Controls.Add(this.huruf_H);
            this.panel_PlayGame.Controls.Add(this.huruf_G);
            this.panel_PlayGame.Controls.Add(this.huruf_F);
            this.panel_PlayGame.Controls.Add(this.huruf_D);
            this.panel_PlayGame.Controls.Add(this.huruf_S);
            this.panel_PlayGame.Controls.Add(this.huruf_A);
            this.panel_PlayGame.Controls.Add(this.huruf_P);
            this.panel_PlayGame.Controls.Add(this.huruf_O);
            this.panel_PlayGame.Controls.Add(this.huruf_I);
            this.panel_PlayGame.Controls.Add(this.huruf_U);
            this.panel_PlayGame.Controls.Add(this.huruf_Y);
            this.panel_PlayGame.Controls.Add(this.huruf_T);
            this.panel_PlayGame.Controls.Add(this.huruf_R);
            this.panel_PlayGame.Controls.Add(this.huruf_E);
            this.panel_PlayGame.Controls.Add(this.huruf_W);
            this.panel_PlayGame.Controls.Add(this.huruf_Q);
            this.panel_PlayGame.Location = new System.Drawing.Point(35, 42);
            this.panel_PlayGame.Name = "panel_PlayGame";
            this.panel_PlayGame.Size = new System.Drawing.Size(1062, 603);
            this.panel_PlayGame.TabIndex = 33;
            this.panel_PlayGame.Visible = false;
            // 
            // panel_Utama
            // 
            this.panel_Utama.BackColor = System.Drawing.SystemColors.Info;
            this.panel_Utama.Controls.Add(this.play_btn);
            this.panel_Utama.Controls.Add(this.kata_2);
            this.panel_Utama.Controls.Add(this.kata_3);
            this.panel_Utama.Controls.Add(this.kata_5);
            this.panel_Utama.Controls.Add(this.kata_4);
            this.panel_Utama.Controls.Add(this.kata_1);
            this.panel_Utama.Controls.Add(this.label5);
            this.panel_Utama.Controls.Add(this.label4);
            this.panel_Utama.Controls.Add(this.label3);
            this.panel_Utama.Controls.Add(this.label2);
            this.panel_Utama.Controls.Add(this.label1);
            this.panel_Utama.Location = new System.Drawing.Point(72, 12);
            this.panel_Utama.Name = "panel_Utama";
            this.panel_Utama.Size = new System.Drawing.Size(1056, 597);
            this.panel_Utama.TabIndex = 34;
            // 
            // play_btn
            // 
            this.play_btn.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.play_btn.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.play_btn.Location = new System.Drawing.Point(279, 284);
            this.play_btn.Name = "play_btn";
            this.play_btn.Size = new System.Drawing.Size(101, 44);
            this.play_btn.TabIndex = 10;
            this.play_btn.Text = "  PLAY";
            this.play_btn.Click += new System.EventHandler(this.play_btn_Click);
            // 
            // kata_2
            // 
            this.kata_2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.kata_2.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_2.Location = new System.Drawing.Point(176, 83);
            this.kata_2.Name = "kata_2";
            this.kata_2.Size = new System.Drawing.Size(334, 44);
            this.kata_2.TabIndex = 9;
            // 
            // kata_3
            // 
            this.kata_3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.kata_3.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_3.Location = new System.Drawing.Point(176, 133);
            this.kata_3.Name = "kata_3";
            this.kata_3.Size = new System.Drawing.Size(334, 44);
            this.kata_3.TabIndex = 8;
            // 
            // kata_5
            // 
            this.kata_5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.kata_5.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_5.Location = new System.Drawing.Point(176, 234);
            this.kata_5.Name = "kata_5";
            this.kata_5.Size = new System.Drawing.Size(334, 44);
            this.kata_5.TabIndex = 7;
            // 
            // kata_4
            // 
            this.kata_4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.kata_4.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_4.Location = new System.Drawing.Point(176, 184);
            this.kata_4.Name = "kata_4";
            this.kata_4.Size = new System.Drawing.Size(334, 44);
            this.kata_4.TabIndex = 6;
            // 
            // kata_1
            // 
            this.kata_1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.kata_1.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata_1.Location = new System.Drawing.Point(176, 33);
            this.kata_1.Name = "kata_1";
            this.kata_1.Size = new System.Drawing.Size(334, 44);
            this.kata_1.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "kata kelima";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "kata keempat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "kata ketiga";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "kata kedua";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "kata pertama";
            // 
            // panel_win
            // 
            this.panel_win.Controls.Add(this.pictureBox1);
            this.panel_win.Location = new System.Drawing.Point(12, 108);
            this.panel_win.Name = "panel_win";
            this.panel_win.Size = new System.Drawing.Size(1051, 591);
            this.panel_win.TabIndex = 11;
            this.panel_win.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Game.Properties.Resources.oceanmam_fnaf;
            this.pictureBox1.Location = new System.Drawing.Point(43, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(497, 373);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 629);
            this.Controls.Add(this.panel_win);
            this.Controls.Add(this.panel_Utama);
            this.Controls.Add(this.panel_PlayGame);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_PlayGame.ResumeLayout(false);
            this.panel_PlayGame.PerformLayout();
            this.panel_Utama.ResumeLayout(false);
            this.panel_Utama.PerformLayout();
            this.panel_win.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button huruf_Q;
        private System.Windows.Forms.Button huruf_W;
        private System.Windows.Forms.Button huruf_E;
        private System.Windows.Forms.Button huruf_R;
        private System.Windows.Forms.Button huruf_T;
        private System.Windows.Forms.Button huruf_Y;
        private System.Windows.Forms.Button huruf_U;
        private System.Windows.Forms.Button huruf_I;
        private System.Windows.Forms.Button huruf_O;
        private System.Windows.Forms.Button huruf_P;
        private System.Windows.Forms.Button huruf_L;
        private System.Windows.Forms.Button huruf_K;
        private System.Windows.Forms.Button huruf_J;
        private System.Windows.Forms.Button huruf_H;
        private System.Windows.Forms.Button huruf_G;
        private System.Windows.Forms.Button huruf_F;
        private System.Windows.Forms.Button huruf_D;
        private System.Windows.Forms.Button huruf_S;
        private System.Windows.Forms.Button huruf_A;
        private System.Windows.Forms.Button huruf_M;
        private System.Windows.Forms.Button huruf_N;
        private System.Windows.Forms.Button huruf_B;
        private System.Windows.Forms.Button huruf_V;
        private System.Windows.Forms.Button huruf_C;
        private System.Windows.Forms.Button huruf_X;
        private System.Windows.Forms.Button huruf_Z;
        private System.Windows.Forms.Label kata_kedua;
        private System.Windows.Forms.Label kata_keempat;
        private System.Windows.Forms.Label kata_ketiga;
        private System.Windows.Forms.Label kata_pertama;
        private System.Windows.Forms.Label kata_kelima;
        private System.Windows.Forms.Panel panel_PlayGame;
        private System.Windows.Forms.Panel panel_Utama;
        private System.Windows.Forms.TextBox kata_2;
        private System.Windows.Forms.TextBox kata_3;
        private System.Windows.Forms.TextBox kata_5;
        private System.Windows.Forms.TextBox kata_4;
        private System.Windows.Forms.TextBox kata_1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox play_btn;
        private System.Windows.Forms.Panel panel_win;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

