﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        private List<string> huruf = new List<string>() { "", "", "", "", "" };
        private int IndexWin = 0;
        private string huruf_ygdipencet = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void play_btn_Click(object sender, EventArgs e)
        {
            int word1 = kata_1.Text.Length;
            int word2 = kata_2.Text.Length;
            int word3 = kata_3.Text.Length;
            int word4 = kata_4.Text.Length;
            int word5 = kata_5.Text.Length;

            if (word1 == 5 && word2 == 5 && word3 == 5 && word4 == 5 && word5 == 5 &&
                kata_1.Text != kata_2.Text && kata_1.Text != kata_3.Text && kata_1.Text != kata_4.Text && kata_1.Text != kata_5.Text &&
                kata_2.Text != kata_3.Text && kata_2.Text != kata_4.Text && kata_2.Text != kata_5.Text &&
                kata_3.Text != kata_4.Text && kata_3.Text != kata_5.Text &&
                kata_4.Text != kata_5.Text)
            {
                panel_PlayGame.Visible = true;
                panel_Utama.Visible = false;
                Random rnd = new Random();
                int angkaRandom = rnd.Next(1, 6);
                string kataAcak = "";
                if (angkaRandom == 1)
                {
                    kataAcak = kata_1.Text;
                }
                else if (angkaRandom == 2)
                {
                    kataAcak = kata_2.Text;
                }
                else if (angkaRandom == 3)
                {
                    kataAcak = kata_3.Text;
                }
                else if (angkaRandom == 4)
                {
                    kataAcak = kata_4.Text;
                }
                else if (angkaRandom == 5)
                {
                    kataAcak = kata_5.Text;
                }
                int i = 0;
                foreach (char hrf in kataAcak)
                {
                    string hrf_hrf = hrf.ToString();
                    huruf[i] = hrf_hrf;
                    i++;
                }
            }
            else
            {
                MessageBox.Show("ERROR ERROR");
            }
        }
        private void UpdateLabelWithHuruf()
        {
            if (huruf_ygdipencet == huruf[0])
            {
                kata_pertama.Text = huruf_ygdipencet;
                IndexWin++;
            }
            if (huruf_ygdipencet == huruf[1])
            {
                kata_kedua.Text = huruf_ygdipencet;
                IndexWin++;
            }
            if (huruf_ygdipencet == huruf[2])
            {
                kata_ketiga.Text = huruf_ygdipencet;
                IndexWin++;
            }
            if (huruf_ygdipencet == huruf[3])
            {
                kata_keempat.Text = huruf_ygdipencet;
                IndexWin++;
            }
            if (huruf_ygdipencet == huruf[4])
            {
                kata_kelima.Text = huruf_ygdipencet;
                IndexWin++;
            }
            if (IndexWin == 5)
            {
                MessageBox.Show("Menang!");
                panel_win.Visible = true;
            }
        }
        private void huruf_Q_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "q";
            UpdateLabelWithHuruf();
        }
        private void huruf_T_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "t";
            UpdateLabelWithHuruf();
        }

        private void huruf_Y_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "y";
            UpdateLabelWithHuruf();
        }

        private void huruf_U_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "u";
            UpdateLabelWithHuruf();
        }

        private void huruf_I_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "i";
            UpdateLabelWithHuruf();
        }

        private void huruf_O_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "o";
            UpdateLabelWithHuruf();
        }

        private void huruf_P_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "p";
            UpdateLabelWithHuruf();
        }

        private void huruf_A_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "a";
            UpdateLabelWithHuruf();
        }

        private void huruf_S_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "s";
            UpdateLabelWithHuruf();
        }

        private void huruf_D_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "d";
            UpdateLabelWithHuruf();
        }

        private void huruf_F_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "f";
            UpdateLabelWithHuruf();
        }

        private void huruf_G_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "g";
            UpdateLabelWithHuruf();
        }

        private void huruf_J_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "j";
            UpdateLabelWithHuruf();
        }

        private void huruf_K_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "k";
            UpdateLabelWithHuruf();
        }

        private void huruf_L_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "l";
            UpdateLabelWithHuruf();
        }

        private void huruf_Z_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "z";
            UpdateLabelWithHuruf();
        }

        private void huruf_X_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "x";
            UpdateLabelWithHuruf();
        }

        private void huruf_C_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "c";
            UpdateLabelWithHuruf();
        }

        private void huruf_V_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "v";
            UpdateLabelWithHuruf();
        }

        private void huruf_B_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "b";
            UpdateLabelWithHuruf();
        }

        private void huruf_N_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "n";
            UpdateLabelWithHuruf();
        }

        private void huruf_M_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "m";
            UpdateLabelWithHuruf();
        }

        private void huruf_E_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "e";
            UpdateLabelWithHuruf();
        }

        private void huruf_W_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "w";
            UpdateLabelWithHuruf();
        }

        private void huruf_H_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "h";
            UpdateLabelWithHuruf();
        }

        private void huruf_R_Click(object sender, EventArgs e)
        {
            huruf_ygdipencet = "r";
            UpdateLabelWithHuruf();
        }

        private void jumpscare_Click(object sender, EventArgs e)
        {

        }
    }
}
