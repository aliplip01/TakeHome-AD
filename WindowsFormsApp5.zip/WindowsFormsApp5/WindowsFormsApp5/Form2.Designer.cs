﻿namespace WindowsFormsApp5
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_total = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btn_add = new System.Windows.Forms.Button();
            this.lbl_harga3 = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.gambar3 = new System.Windows.Forms.PictureBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar3)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(714, 401);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(192, 22);
            this.tb_total.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(570, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "TOTAL";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(714, 373);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(192, 22);
            this.tb_subtotal.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(570, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 22);
            this.label1.TabIndex = 8;
            this.label1.Text = "SUB-TOTAL";
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(467, 31);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(548, 318);
            this.dgv.TabIndex = 7;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(205, 315);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(97, 23);
            this.btn_add.TabIndex = 21;
            this.btn_add.Text = "add to cart";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // lbl_harga3
            // 
            this.lbl_harga3.AutoSize = true;
            this.lbl_harga3.Location = new System.Drawing.Point(202, 176);
            this.lbl_harga3.Name = "lbl_harga3";
            this.lbl_harga3.Size = new System.Drawing.Size(72, 16);
            this.lbl_harga3.TabIndex = 20;
            this.lbl_harga3.Text = "Item Name";
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.Location = new System.Drawing.Point(202, 81);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(93, 16);
            this.label_1.TabIndex = 19;
            this.label_1.Text = "Upload Image";
            // 
            // gambar3
            // 
            this.gambar3.Location = new System.Drawing.Point(23, 78);
            this.gambar3.Name = "gambar3";
            this.gambar3.Size = new System.Drawing.Size(155, 260);
            this.gambar3.TabIndex = 18;
            this.gambar3.TabStop = false;
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(301, 78);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(71, 23);
            this.btn_upload.TabIndex = 22;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(301, 173);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(141, 22);
            this.tb_nama.TabIndex = 23;
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(301, 212);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(141, 22);
            this.tb_price.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(202, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Item Price";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 569);
            this.Controls.Add(this.tb_price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.btn_upload);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.lbl_harga3);
            this.Controls.Add(this.label_1);
            this.Controls.Add(this.gambar3);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label lbl_harga3;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.PictureBox gambar3;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.Label label3;
    }
}