﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        DataTable dt_top_wear = new DataTable();
        DataTable dt_buttom_wear = new DataTable();
        DataTable dt_accessories = new DataTable();
        DataTable dt_others = new DataTable();

        DataTable dt_strip = new DataTable();
        public DataTable dt;
        Form2 form2;
        public Form1(Form _form)
        {
            form2 = _form as Form2;
            InitializeComponent();

            dt_top_wear.Columns.Add("name");
            dt_top_wear.Columns.Add("price");
            dt_buttom_wear.Columns.Add("name");
            dt_buttom_wear.Columns.Add("price");
            dt_accessories.Columns.Add("name");
            dt_accessories.Columns.Add("price");
            dt_others.Columns.Add("name");
            dt_others.Columns.Add("price");

            dt_top_wear.Rows.Add("T-Shirt White", "Rp.120.000,00");
            dt_top_wear.Rows.Add("AlRism T-SHirt", "Rp.150.000,00");
            dt_top_wear.Rows.Add("T-SHirt VNeck", "Rp.170.000,00");
            dt_buttom_wear.Rows.Add("Palazzo Pants", "Rp.629.900,00");
            dt_buttom_wear.Rows.Add("Flare Pants", "Rp.1.590.000,00");
            dt_buttom_wear.Rows.Add("Skinny Jeans", "Rp.699.000,00");
            dt_accessories.Rows.Add("Kalung Salib", "Rp.300.000,00");
            dt_accessories.Rows.Add("Tommy Hilfiger", "Rp.712.000,00");
            dt_accessories.Rows.Add("Jam Tangan Rolex", "Rp.90.000.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");

            dt_strip.Columns.Add("Item Name");
            dt_strip.Columns.Add("Quantity");
            dt_strip.Columns.Add("Price");
            dt_strip.Columns.Add("Total");

            dgv.DataSource = dt_strip;

            dt = dt_strip;
        }
        // 0 = name
        // 1 = price
        private void topWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lbl_brg1.Text = dt_top_wear.Rows[0][0].ToString();
            lbl_harga1.Text = dt_top_wear.Rows[0][1].ToString();
            lbl_brg2.Text = dt_top_wear.Rows[1][0].ToString();
            lbl_harga2.Text = dt_top_wear.Rows[1][1].ToString();
            lbl_brg3.Text = dt_top_wear.Rows[2][0].ToString();
            lbl_harga3.Text = dt_top_wear.Rows[2][1].ToString();

            show_picture();
        }

        private void buttomWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lbl_brg1.Text = dt_buttom_wear.Rows[0][0].ToString();
            lbl_harga1.Text = dt_buttom_wear.Rows[0][1].ToString();
            lbl_brg2.Text = dt_buttom_wear.Rows[1][0].ToString();
            lbl_harga2.Text = dt_buttom_wear.Rows[1][1].ToString();
            lbl_brg3.Text = dt_buttom_wear.Rows[2][0].ToString();
            lbl_harga3.Text = dt_buttom_wear.Rows[2][1].ToString();
            show_picture();
        }

        private void accessoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lbl_brg1.Text = dt_accessories.Rows[0][0].ToString();
            lbl_harga1.Text = dt_accessories.Rows[0][1].ToString();
            lbl_brg2.Text = dt_accessories.Rows[1][0].ToString();
            lbl_harga2.Text = dt_accessories.Rows[1][1].ToString();
            lbl_brg3.Text = dt_accessories.Rows[2][0].ToString();
            lbl_harga3.Text = dt_accessories.Rows[2][1].ToString();
            show_picture();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gambar1.Visible = false;
            gambar2.Visible = false;
            gambar3.Visible = false;

            lbl_brg1.Visible = false;
            lbl_brg2.Visible = false;
            lbl_brg3.Visible = false;

            lbl_harga1.Visible = false;
            lbl_harga2.Visible = false;
            lbl_harga3.Visible = false;

            btn_add1.Visible = false;
            btn_add2.Visible = false;
            btn_add3.Visible = false;

            form2 = new Form2(dt_strip, tbsubtotal(), tbtotal());
            form2.FormClosed += Form_FormClosed;
            form2.ShowDialog();
        }
        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (form2.Brg == null)
            {

            }
            else
            {
                string itemName = form2.Brg;
                string itemPrice = form2.Price;
                int quantity = form2.Qty;

                // Hitung total harga
                decimal price = decimal.Parse(itemPrice.Replace("Rp.", "").Replace(".", "").Replace(",", ""));
                decimal total = price * quantity;

                bool itemExists = false;

                // Iterasi melalui setiap baris dalam dt_strip
                for (int i = 0; i < dt_strip.Rows.Count; i++)
                {
                    DataRow row = dt_strip.Rows[i];

                    // Jika nama barang sudah ada, tambahkan ke quantity dan perbarui total harga
                    if (row["Item Name"].ToString() == itemName)
                    {
                        int existingQuantity = int.Parse(row["Quantity"].ToString());
                        row["Quantity"] = existingQuantity + quantity;

                        // Hitung total harga berdasarkan kuantitas baru dan harga per item yang sudah ada
                        decimal existingPrice = decimal.Parse(row["Price"].ToString().Replace("Rp.", "").Replace(".", ""));
                        decimal newTotal = existingPrice * (existingQuantity + quantity);
                        row["Total"] = string.Format("Rp.{0:#,##0.00}", newTotal);

                        itemExists = true;
                        subtotal();
                        break;
                    }
                }

                // Jika barang belum ada, tambahkan sebagai barang baru ke dt_strip dengan quantity 1
                if (!itemExists)
                {
                    dt_strip.Rows.Add(itemName, quantity, string.Format("Rp.{0:#,##0.00}", price), string.Format("Rp.{0:#,##0.00}", total));
                    subtotal();
                }
            }
        }
        private void show_picture()
        {
            gambar1.Visible = true;
            gambar2.Visible = true;
            gambar3.Visible = true;

            lbl_brg1.Visible = true;
            lbl_brg2.Visible = true;
            lbl_brg3.Visible = true;

            lbl_harga1.Visible = true;
            lbl_harga2.Visible = true;
            lbl_harga3.Visible = true;

            btn_add1.Visible = true;
            btn_add2.Visible = true;
            btn_add3.Visible = true;
        }

        private void btn_add1_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lbl_brg1.Text, lbl_harga1.Text);
            subtotal();
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lbl_brg2.Text, lbl_harga2.Text);
            subtotal();
        }

        private void btn_add3_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lbl_brg3.Text, lbl_harga3.Text);
            subtotal();
        }
        private void AddItemToStrip(string itemName, string itemPrice)
        {
            // Hilangkan karakter "Rp." dan ",00" dari string harga
            string cleanPrice = itemPrice.Replace("Rp.", "").Replace(",00", "").Replace(".", "");

            // Konversi string harga menjadi tipe data int
            int harga = int.Parse(cleanPrice);

            bool itemExists = false;

            // Iterasi melalui setiap baris dalam dt_strip
            foreach (DataRow row in dt_strip.Rows)
            {
                // Jika nama barang sudah ada, tambahkan ke quantity dan perbarui total harga
                if (row["Item Name"].ToString() == itemName)
                {
                    int quantity = int.Parse(row["Quantity"].ToString()) + 1;
                    row["Quantity"] = quantity;

                    // Hitung total harga berdasarkan kuantitas baru
                    int totalHarga = harga * quantity;
                    string formattedTotal = string.Format("Rp.{0:#,##0.00}", totalHarga);
                    row["Total"] = formattedTotal;

                    itemExists = true;
                    break;
                }
            }

            // Jika barang belum ada, tambahkan sebagai barang baru ke dt_strip dengan quantity 1
            if (!itemExists)
            {
                dt_strip.Rows.Add(itemName, 1, itemPrice, itemPrice);
            }
        }
        private void subtotal()
        {
            string[] subtotal = new string[dt_strip.Rows.Count];
            for (int i = 0; i < dt_strip.Rows.Count; i++)
            {
                subtotal[i] = dt_strip.Rows[i]["Total"].ToString().Replace("Rp.", "").Replace(".", "").Replace(",00", "");
            }
            decimal total = 0; 
            for (int i = 0; i < dt_strip.Rows.Count; i++)
            {
                total += Convert.ToDecimal(subtotal[i].ToString());
            }
            tb_subtotal.Text = String.Format("Rp.{0:#,##0.00}", total);
            decimal tax = total + (total / 10);
            tb_total.Text = String.Format("Rp.{0:#,##0.00}", tax);
        }
        public string tbsubtotal()
        {
            return tb_subtotal.Text;
        }
        public string tbtotal()
        {
            return tb_total.Text;
        }
    }
}
