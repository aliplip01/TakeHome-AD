﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_brg1 = new System.Windows.Forms.Label();
            this.lbl_harga1 = new System.Windows.Forms.Label();
            this.lbl_harga2 = new System.Windows.Forms.Label();
            this.lbl_brg2 = new System.Windows.Forms.Label();
            this.lbl_harga3 = new System.Windows.Forms.Label();
            this.lbl_brg3 = new System.Windows.Forms.Label();
            this.btn_add1 = new System.Windows.Forms.Button();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.btn_add3 = new System.Windows.Forms.Button();
            this.gambar3 = new System.Windows.Forms.PictureBox();
            this.gambar2 = new System.Windows.Forms.PictureBox();
            this.gambar1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.buttomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1066, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            this.topWearToolStripMenuItem.Click += new System.EventHandler(this.topWearToolStripMenuItem_Click);
            // 
            // buttomWearToolStripMenuItem
            // 
            this.buttomWearToolStripMenuItem.Name = "buttomWearToolStripMenuItem";
            this.buttomWearToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.buttomWearToolStripMenuItem.Text = "Buttom Wear";
            this.buttomWearToolStripMenuItem.Click += new System.EventHandler(this.buttomWearToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            this.accessoriesToolStripMenuItem.Click += new System.EventHandler(this.accessoriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(495, 46);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(535, 318);
            this.dgv.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(583, 378);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "SUB-TOTAL";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(727, 380);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(192, 22);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(727, 408);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(192, 22);
            this.tb_total.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(583, 406);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "TOTAL";
            // 
            // lbl_brg1
            // 
            this.lbl_brg1.AutoSize = true;
            this.lbl_brg1.Location = new System.Drawing.Point(9, 306);
            this.lbl_brg1.Name = "lbl_brg1";
            this.lbl_brg1.Size = new System.Drawing.Size(41, 16);
            this.lbl_brg1.TabIndex = 9;
            this.lbl_brg1.Text = "nama";
            this.lbl_brg1.Visible = false;
            // 
            // lbl_harga1
            // 
            this.lbl_harga1.AutoSize = true;
            this.lbl_harga1.Location = new System.Drawing.Point(9, 322);
            this.lbl_harga1.Name = "lbl_harga1";
            this.lbl_harga1.Size = new System.Drawing.Size(42, 16);
            this.lbl_harga1.TabIndex = 10;
            this.lbl_harga1.Text = "harga";
            this.lbl_harga1.Visible = false;
            // 
            // lbl_harga2
            // 
            this.lbl_harga2.AutoSize = true;
            this.lbl_harga2.Location = new System.Drawing.Point(170, 322);
            this.lbl_harga2.Name = "lbl_harga2";
            this.lbl_harga2.Size = new System.Drawing.Size(42, 16);
            this.lbl_harga2.TabIndex = 12;
            this.lbl_harga2.Text = "harga";
            this.lbl_harga2.Visible = false;
            // 
            // lbl_brg2
            // 
            this.lbl_brg2.AutoSize = true;
            this.lbl_brg2.Location = new System.Drawing.Point(170, 306);
            this.lbl_brg2.Name = "lbl_brg2";
            this.lbl_brg2.Size = new System.Drawing.Size(41, 16);
            this.lbl_brg2.TabIndex = 11;
            this.lbl_brg2.Text = "nama";
            this.lbl_brg2.Visible = false;
            // 
            // lbl_harga3
            // 
            this.lbl_harga3.AutoSize = true;
            this.lbl_harga3.Location = new System.Drawing.Point(331, 322);
            this.lbl_harga3.Name = "lbl_harga3";
            this.lbl_harga3.Size = new System.Drawing.Size(42, 16);
            this.lbl_harga3.TabIndex = 14;
            this.lbl_harga3.Text = "harga";
            this.lbl_harga3.Visible = false;
            // 
            // lbl_brg3
            // 
            this.lbl_brg3.AutoSize = true;
            this.lbl_brg3.Location = new System.Drawing.Point(334, 306);
            this.lbl_brg3.Name = "lbl_brg3";
            this.lbl_brg3.Size = new System.Drawing.Size(41, 16);
            this.lbl_brg3.TabIndex = 13;
            this.lbl_brg3.Text = "nama";
            this.lbl_brg3.Visible = false;
            // 
            // btn_add1
            // 
            this.btn_add1.Location = new System.Drawing.Point(12, 341);
            this.btn_add1.Name = "btn_add1";
            this.btn_add1.Size = new System.Drawing.Size(97, 23);
            this.btn_add1.TabIndex = 15;
            this.btn_add1.Text = "add to cart";
            this.btn_add1.UseVisualStyleBackColor = true;
            this.btn_add1.Visible = false;
            this.btn_add1.Click += new System.EventHandler(this.btn_add1_Click);
            // 
            // btn_add2
            // 
            this.btn_add2.Location = new System.Drawing.Point(173, 341);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(97, 23);
            this.btn_add2.TabIndex = 16;
            this.btn_add2.Text = "add to cart";
            this.btn_add2.UseVisualStyleBackColor = true;
            this.btn_add2.Visible = false;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // btn_add3
            // 
            this.btn_add3.Location = new System.Drawing.Point(334, 341);
            this.btn_add3.Name = "btn_add3";
            this.btn_add3.Size = new System.Drawing.Size(97, 23);
            this.btn_add3.TabIndex = 17;
            this.btn_add3.Text = "add to cart";
            this.btn_add3.UseVisualStyleBackColor = true;
            this.btn_add3.Visible = false;
            this.btn_add3.Click += new System.EventHandler(this.btn_add3_Click);
            // 
            // gambar3
            // 
            this.gambar3.Image = global::WindowsFormsApp5.Properties.Resources._0417_Cover;
            this.gambar3.Location = new System.Drawing.Point(334, 43);
            this.gambar3.Name = "gambar3";
            this.gambar3.Size = new System.Drawing.Size(155, 260);
            this.gambar3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambar3.TabIndex = 8;
            this.gambar3.TabStop = false;
            this.gambar3.Visible = false;
            // 
            // gambar2
            // 
            this.gambar2.Image = global::WindowsFormsApp5.Properties.Resources.printer_ink_logo_icon_bird_vector_26007098;
            this.gambar2.Location = new System.Drawing.Point(173, 43);
            this.gambar2.Name = "gambar2";
            this.gambar2.Size = new System.Drawing.Size(155, 260);
            this.gambar2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.gambar2.TabIndex = 7;
            this.gambar2.TabStop = false;
            this.gambar2.Visible = false;
            // 
            // gambar1
            // 
            this.gambar1.Image = global::WindowsFormsApp5.Properties.Resources.unnamed;
            this.gambar1.Location = new System.Drawing.Point(12, 43);
            this.gambar1.Name = "gambar1";
            this.gambar1.Size = new System.Drawing.Size(155, 260);
            this.gambar1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.gambar1.TabIndex = 1;
            this.gambar1.TabStop = false;
            this.gambar1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 483);
            this.Controls.Add(this.btn_add3);
            this.Controls.Add(this.btn_add2);
            this.Controls.Add(this.btn_add1);
            this.Controls.Add(this.lbl_harga3);
            this.Controls.Add(this.lbl_brg3);
            this.Controls.Add(this.lbl_harga2);
            this.Controls.Add(this.lbl_brg2);
            this.Controls.Add(this.lbl_harga1);
            this.Controls.Add(this.lbl_brg1);
            this.Controls.Add(this.gambar3);
            this.Controls.Add(this.gambar2);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.gambar1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.PictureBox gambar1;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox gambar2;
        private System.Windows.Forms.PictureBox gambar3;
        private System.Windows.Forms.Label lbl_brg1;
        private System.Windows.Forms.Label lbl_harga1;
        private System.Windows.Forms.Label lbl_harga2;
        private System.Windows.Forms.Label lbl_brg2;
        private System.Windows.Forms.Label lbl_harga3;
        private System.Windows.Forms.Label lbl_brg3;
        private System.Windows.Forms.Button btn_add1;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.Button btn_add3;
    }
}

