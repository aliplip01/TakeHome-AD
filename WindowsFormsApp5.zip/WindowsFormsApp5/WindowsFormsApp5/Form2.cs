﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        public string Brg { get; private set; }
        public int Qty { get; private set; }
        public string Price { get; private set; }

        private DataTable dt;

        public Form2(DataTable dt, string subtotal, string total)
        {
            InitializeComponent();

            dgv.DataSource = dt;

            tb_subtotal.Text = subtotal;
            tb_total.Text = total;
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            if(Brg == tb_nama.Text)
            {
                Qty++;
            }
            else
            {
                Brg = tb_nama.Text;
                Price = tb_price.Text;
                Qty = 1;
            }
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }
}
