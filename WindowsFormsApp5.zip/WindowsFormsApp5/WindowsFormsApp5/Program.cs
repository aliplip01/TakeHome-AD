﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Buat instance DataTable di Form1
            Form1 form1 = new Form1(null);

            // Kirim instance DataTable ke Form2
            Form2 form2 = new Form2(form1.dt, form1.tbsubtotal(), form1.tbtotal());

            // Jalankan Form1
            Application.Run(form1);
        }
    }
}
