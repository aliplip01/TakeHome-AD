﻿namespace sepak_bola
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel_gambarutama = new System.Windows.Forms.Panel();
            this.cbx_PPosition = new System.Windows.Forms.ComboBox();
            this.lbl_JP = new System.Windows.Forms.Label();
            this.btn_remove = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.lbl_PPosition = new System.Windows.Forms.Label();
            this.text_PNumber = new System.Windows.Forms.TextBox();
            this.lbl_PNumber = new System.Windows.Forms.Label();
            this.lbl_PName = new System.Windows.Forms.Label();
            this.text_PName = new System.Windows.Forms.TextBox();
            this.lbl_addPlayer = new System.Windows.Forms.Label();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.lbl_TCity = new System.Windows.Forms.Label();
            this.text_TCountry = new System.Windows.Forms.TextBox();
            this.text_TCity = new System.Windows.Forms.TextBox();
            this.lbl_TCountry = new System.Windows.Forms.Label();
            this.lbl_TName = new System.Windows.Forms.Label();
            this.text_TName = new System.Windows.Forms.TextBox();
            this.lbl_AT = new System.Windows.Forms.Label();
            this.cbx_CTeam = new System.Windows.Forms.ComboBox();
            this.cbx_CCountry = new System.Windows.Forms.ComboBox();
            this.lbl_CCountry = new System.Windows.Forms.Label();
            this.lbl_CTeam = new System.Windows.Forms.Label();
            this.lbl_soccer_TL = new System.Windows.Forms.Label();
            this.listPlayer = new System.Windows.Forms.ListBox();
            this.gambar_game_bola = new System.Windows.Forms.PictureBox();
            this.panel_gambarutama.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar_game_bola)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_gambarutama
            // 
            this.panel_gambarutama.Controls.Add(this.cbx_PPosition);
            this.panel_gambarutama.Controls.Add(this.lbl_JP);
            this.panel_gambarutama.Controls.Add(this.btn_remove);
            this.panel_gambarutama.Controls.Add(this.pictureBox1);
            this.panel_gambarutama.Controls.Add(this.btn_addPlayer);
            this.panel_gambarutama.Controls.Add(this.lbl_PPosition);
            this.panel_gambarutama.Controls.Add(this.text_PNumber);
            this.panel_gambarutama.Controls.Add(this.lbl_PNumber);
            this.panel_gambarutama.Controls.Add(this.lbl_PName);
            this.panel_gambarutama.Controls.Add(this.text_PName);
            this.panel_gambarutama.Controls.Add(this.lbl_addPlayer);
            this.panel_gambarutama.Controls.Add(this.btn_addTeam);
            this.panel_gambarutama.Controls.Add(this.lbl_TCity);
            this.panel_gambarutama.Controls.Add(this.text_TCountry);
            this.panel_gambarutama.Controls.Add(this.text_TCity);
            this.panel_gambarutama.Controls.Add(this.lbl_TCountry);
            this.panel_gambarutama.Controls.Add(this.lbl_TName);
            this.panel_gambarutama.Controls.Add(this.text_TName);
            this.panel_gambarutama.Controls.Add(this.lbl_AT);
            this.panel_gambarutama.Controls.Add(this.cbx_CTeam);
            this.panel_gambarutama.Controls.Add(this.cbx_CCountry);
            this.panel_gambarutama.Controls.Add(this.lbl_CCountry);
            this.panel_gambarutama.Controls.Add(this.lbl_CTeam);
            this.panel_gambarutama.Controls.Add(this.lbl_soccer_TL);
            this.panel_gambarutama.Controls.Add(this.listPlayer);
            this.panel_gambarutama.Controls.Add(this.gambar_game_bola);
            this.panel_gambarutama.Location = new System.Drawing.Point(2, 0);
            this.panel_gambarutama.Name = "panel_gambarutama";
            this.panel_gambarutama.Size = new System.Drawing.Size(1128, 658);
            this.panel_gambarutama.TabIndex = 0;
            // 
            // cbx_PPosition
            // 
            this.cbx_PPosition.FormattingEnabled = true;
            this.cbx_PPosition.Items.AddRange(new object[] {
            "G.K",
            "D.F",
            "M.F",
            "F.W"});
            this.cbx_PPosition.Location = new System.Drawing.Point(613, 325);
            this.cbx_PPosition.Name = "cbx_PPosition";
            this.cbx_PPosition.Size = new System.Drawing.Size(203, 24);
            this.cbx_PPosition.TabIndex = 27;
            // 
            // lbl_JP
            // 
            this.lbl_JP.AutoSize = true;
            this.lbl_JP.Font = new System.Drawing.Font("Mongolian Baiti", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_JP.Location = new System.Drawing.Point(209, 594);
            this.lbl_JP.Name = "lbl_JP";
            this.lbl_JP.Size = new System.Drawing.Size(271, 35);
            this.lbl_JP.TabIndex = 26;
            this.lbl_JP.Text = "Jumlah Pemain = ";
            // 
            // btn_remove
            // 
            this.btn_remove.Font = new System.Drawing.Font("Mongolian Baiti", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove.Location = new System.Drawing.Point(2, 587);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(201, 49);
            this.btn_remove.TabIndex = 25;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(843, 171);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 249);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addPlayer.Location = new System.Drawing.Point(613, 356);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(86, 27);
            this.btn_addPlayer.TabIndex = 23;
            this.btn_addPlayer.Text = "Add";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // lbl_PPosition
            // 
            this.lbl_PPosition.AutoSize = true;
            this.lbl_PPosition.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PPosition.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PPosition.Location = new System.Drawing.Point(450, 329);
            this.lbl_PPosition.Name = "lbl_PPosition";
            this.lbl_PPosition.Size = new System.Drawing.Size(149, 21);
            this.lbl_PPosition.TabIndex = 22;
            this.lbl_PPosition.Text = "Player Position";
            // 
            // text_PNumber
            // 
            this.text_PNumber.Location = new System.Drawing.Point(613, 300);
            this.text_PNumber.Name = "text_PNumber";
            this.text_PNumber.Size = new System.Drawing.Size(203, 22);
            this.text_PNumber.TabIndex = 21;
            // 
            // lbl_PNumber
            // 
            this.lbl_PNumber.AutoSize = true;
            this.lbl_PNumber.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PNumber.Location = new System.Drawing.Point(450, 301);
            this.lbl_PNumber.Name = "lbl_PNumber";
            this.lbl_PNumber.Size = new System.Drawing.Size(146, 21);
            this.lbl_PNumber.TabIndex = 19;
            this.lbl_PNumber.Text = "Player Number";
            // 
            // lbl_PName
            // 
            this.lbl_PName.AutoSize = true;
            this.lbl_PName.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PName.Location = new System.Drawing.Point(450, 273);
            this.lbl_PName.Name = "lbl_PName";
            this.lbl_PName.Size = new System.Drawing.Size(126, 21);
            this.lbl_PName.TabIndex = 18;
            this.lbl_PName.Text = "Player Name";
            // 
            // text_PName
            // 
            this.text_PName.Location = new System.Drawing.Point(613, 274);
            this.text_PName.Name = "text_PName";
            this.text_PName.Size = new System.Drawing.Size(203, 22);
            this.text_PName.TabIndex = 17;
            // 
            // lbl_addPlayer
            // 
            this.lbl_addPlayer.AutoSize = true;
            this.lbl_addPlayer.Font = new System.Drawing.Font("Mongolian Baiti", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addPlayer.Location = new System.Drawing.Point(450, 229);
            this.lbl_addPlayer.Name = "lbl_addPlayer";
            this.lbl_addPlayer.Size = new System.Drawing.Size(201, 31);
            this.lbl_addPlayer.TabIndex = 16;
            this.lbl_addPlayer.Text = "Adding Player";
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addTeam.Location = new System.Drawing.Point(902, 129);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(86, 27);
            this.btn_addTeam.TabIndex = 15;
            this.btn_addTeam.Text = "Add";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // lbl_TCity
            // 
            this.lbl_TCity.AutoSize = true;
            this.lbl_TCity.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TCity.Location = new System.Drawing.Point(698, 102);
            this.lbl_TCity.Name = "lbl_TCity";
            this.lbl_TCity.Size = new System.Drawing.Size(105, 21);
            this.lbl_TCity.TabIndex = 14;
            this.lbl_TCity.Text = "Team City";
            // 
            // text_TCountry
            // 
            this.text_TCountry.Location = new System.Drawing.Point(843, 73);
            this.text_TCountry.Name = "text_TCountry";
            this.text_TCountry.Size = new System.Drawing.Size(203, 22);
            this.text_TCountry.TabIndex = 13;
            // 
            // text_TCity
            // 
            this.text_TCity.Location = new System.Drawing.Point(843, 101);
            this.text_TCity.Name = "text_TCity";
            this.text_TCity.Size = new System.Drawing.Size(203, 22);
            this.text_TCity.TabIndex = 12;
            // 
            // lbl_TCountry
            // 
            this.lbl_TCountry.AutoSize = true;
            this.lbl_TCountry.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TCountry.Location = new System.Drawing.Point(698, 74);
            this.lbl_TCountry.Name = "lbl_TCountry";
            this.lbl_TCountry.Size = new System.Drawing.Size(139, 21);
            this.lbl_TCountry.TabIndex = 11;
            this.lbl_TCountry.Text = "Team Country";
            // 
            // lbl_TName
            // 
            this.lbl_TName.AutoSize = true;
            this.lbl_TName.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TName.Location = new System.Drawing.Point(698, 46);
            this.lbl_TName.Name = "lbl_TName";
            this.lbl_TName.Size = new System.Drawing.Size(118, 21);
            this.lbl_TName.TabIndex = 10;
            this.lbl_TName.Text = "Team Name";
            // 
            // text_TName
            // 
            this.text_TName.Location = new System.Drawing.Point(843, 45);
            this.text_TName.Name = "text_TName";
            this.text_TName.Size = new System.Drawing.Size(203, 22);
            this.text_TName.TabIndex = 9;
            // 
            // lbl_AT
            // 
            this.lbl_AT.AutoSize = true;
            this.lbl_AT.Font = new System.Drawing.Font("Mongolian Baiti", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AT.Location = new System.Drawing.Point(696, 10);
            this.lbl_AT.Name = "lbl_AT";
            this.lbl_AT.Size = new System.Drawing.Size(190, 31);
            this.lbl_AT.TabIndex = 8;
            this.lbl_AT.Text = "Adding Team";
            // 
            // cbx_CTeam
            // 
            this.cbx_CTeam.FormattingEnabled = true;
            this.cbx_CTeam.Location = new System.Drawing.Point(456, 119);
            this.cbx_CTeam.Name = "cbx_CTeam";
            this.cbx_CTeam.Size = new System.Drawing.Size(223, 24);
            this.cbx_CTeam.TabIndex = 7;
            this.cbx_CTeam.SelectedIndexChanged += new System.EventHandler(this.cbx_CTeam_SelectedIndexChanged);
            // 
            // cbx_CCountry
            // 
            this.cbx_CCountry.FormattingEnabled = true;
            this.cbx_CCountry.Location = new System.Drawing.Point(456, 68);
            this.cbx_CCountry.Name = "cbx_CCountry";
            this.cbx_CCountry.Size = new System.Drawing.Size(223, 24);
            this.cbx_CCountry.TabIndex = 6;
            this.cbx_CCountry.SelectedIndexChanged += new System.EventHandler(this.cbx_CCountry_SelectedIndexChanged);
            this.cbx_CCountry.Click += new System.EventHandler(this.cbx_CCountry_Click);
            // 
            // lbl_CCountry
            // 
            this.lbl_CCountry.AutoSize = true;
            this.lbl_CCountry.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CCountry.Location = new System.Drawing.Point(452, 44);
            this.lbl_CCountry.Name = "lbl_CCountry";
            this.lbl_CCountry.Size = new System.Drawing.Size(155, 21);
            this.lbl_CCountry.TabIndex = 4;
            this.lbl_CCountry.Text = "Choose Country";
            // 
            // lbl_CTeam
            // 
            this.lbl_CTeam.AutoSize = true;
            this.lbl_CTeam.Font = new System.Drawing.Font("Mongolian Baiti", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CTeam.Location = new System.Drawing.Point(452, 95);
            this.lbl_CTeam.Name = "lbl_CTeam";
            this.lbl_CTeam.Size = new System.Drawing.Size(132, 21);
            this.lbl_CTeam.TabIndex = 3;
            this.lbl_CTeam.Text = "Choose Team";
            // 
            // lbl_soccer_TL
            // 
            this.lbl_soccer_TL.AutoSize = true;
            this.lbl_soccer_TL.BackColor = System.Drawing.Color.Transparent;
            this.lbl_soccer_TL.Font = new System.Drawing.Font("Mongolian Baiti", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soccer_TL.Location = new System.Drawing.Point(450, 10);
            this.lbl_soccer_TL.Name = "lbl_soccer_TL";
            this.lbl_soccer_TL.Size = new System.Drawing.Size(240, 31);
            this.lbl_soccer_TL.TabIndex = 2;
            this.lbl_soccer_TL.Text = "Soccer Team List";
            // 
            // listPlayer
            // 
            this.listPlayer.FormattingEnabled = true;
            this.listPlayer.ItemHeight = 16;
            this.listPlayer.Location = new System.Drawing.Point(2, 0);
            this.listPlayer.Name = "listPlayer";
            this.listPlayer.Size = new System.Drawing.Size(442, 580);
            this.listPlayer.TabIndex = 1;
            // 
            // gambar_game_bola
            // 
            this.gambar_game_bola.Image = ((System.Drawing.Image)(resources.GetObject("gambar_game_bola.Image")));
            this.gambar_game_bola.Location = new System.Drawing.Point(-9, 0);
            this.gambar_game_bola.Name = "gambar_game_bola";
            this.gambar_game_bola.Size = new System.Drawing.Size(1146, 670);
            this.gambar_game_bola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambar_game_bola.TabIndex = 0;
            this.gambar_game_bola.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 658);
            this.Controls.Add(this.panel_gambarutama);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_gambarutama.ResumeLayout(false);
            this.panel_gambarutama.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambar_game_bola)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_gambarutama;
        private System.Windows.Forms.ListBox listPlayer;
        private System.Windows.Forms.Label lbl_soccer_TL;
        private System.Windows.Forms.Label lbl_CCountry;
        private System.Windows.Forms.Label lbl_CTeam;
        private System.Windows.Forms.PictureBox gambar_game_bola;
        private System.Windows.Forms.ComboBox cbx_CCountry;
        private System.Windows.Forms.ComboBox cbx_CTeam;
        private System.Windows.Forms.Label lbl_TCity;
        private System.Windows.Forms.TextBox text_TCountry;
        private System.Windows.Forms.TextBox text_TCity;
        private System.Windows.Forms.Label lbl_TCountry;
        private System.Windows.Forms.Label lbl_TName;
        private System.Windows.Forms.TextBox text_TName;
        private System.Windows.Forms.Label lbl_AT;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Button btn_addPlayer;
        private System.Windows.Forms.Label lbl_PPosition;
        private System.Windows.Forms.TextBox text_PNumber;
        private System.Windows.Forms.Label lbl_PNumber;
        private System.Windows.Forms.Label lbl_PName;
        private System.Windows.Forms.TextBox text_PName;
        private System.Windows.Forms.Label lbl_addPlayer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label lbl_JP;
        private System.Windows.Forms.ComboBox cbx_PPosition;
    }
}

