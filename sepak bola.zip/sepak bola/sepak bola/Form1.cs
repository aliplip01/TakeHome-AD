﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace sepak_bola
{
    public partial class Form1 : Form
    {
        DataTable player = new DataTable();
        public Form1()
        {
            InitializeComponent();
            datatable();
        }
        private void datatable()
        {
            player.Columns.Add("Negara");
            player.Columns.Add("Team");
            player.Columns.Add("No");
            player.Columns.Add("nama");
            player.Columns.Add("role");
            player.Rows.Add("indonesia", "Persebaya", "21", "Ernando Ari Sutaryadi", "GK");
            player.Rows.Add("indonesia", "Persebaya", "52", "Andhika Ramadhani", "GK");
            player.Rows.Add("indonesia", "Persebaya", "26", "Silva Paixao Yan Victor", "DF");
            player.Rows.Add("indonesia", "Persebaya", "42", "Arief Catur Prasetya", "DF");
            player.Rows.Add("indonesia", "Persebaya", "5", "Dusan Stevanovic", "DF");
            player.Rows.Add("indonesia", "Persebaya", "96", "Muhammad Hidayat", "MF");
            player.Rows.Add("indonesia", "Persebaya", "8", "Andre Oktaviansyah", "MF");
            player.Rows.Add("indonesia", "Persebaya", "28", "Alfan Suaib", "MF");
            player.Rows.Add("indonesia", "Persebaya", "30", "Robson Duarte", "FW");
            player.Rows.Add("indonesia", "Persebaya", "9", "Paulo Henrique", "FW");
            player.Rows.Add("indonesia", "Persebaya", "99", "Bruno Moreira Soares", "FW");
            player.Rows.Add("indonesia", "Arema FC", "23", "Teguh Amirrudin", "GK");
            player.Rows.Add("indonesia", "Arema FC", "22", "Dicki Agung", "GK");
            player.Rows.Add("indonesia", "Arema FC", "5", "Bagas Adi", "DF");
            player.Rows.Add("indonesia", "Arema FC", "4", "Syaeful Anwar", "DF");
            player.Rows.Add("indonesia", "Arema FC", "3", "Bayu Aji", "DF");
            player.Rows.Add("indonesia", "Arema FC", "14", "Jayus Hariono", "MF");
            player.Rows.Add("indonesia", "Arema FC", "8", "Arkhan Fikri", "MF");
            player.Rows.Add("indonesia", "Arema FC", "19", "Achmad Maulana", "MF");
            player.Rows.Add("indonesia", "Arema FC", "10", "Muhammad Rafli", "FW");
            player.Rows.Add("indonesia", "Arema FC", "17", "Ginanjar Wahyu", "FW");
            player.Rows.Add("indonesia", "Arema FC", "86", "Greg Nwokolo", "FW");
            player.Rows.Add("britania raya", "Liverpool", "1", "Alisson Becker", "GK");
            player.Rows.Add("britania raya", "Liverpool", "13", "Adrian", "GK");
            player.Rows.Add("britania raya", "Liverpool", "2", "Joe Gomez", "DF");
            player.Rows.Add("britania raya", "Liverpool", "5", "Ibrahima Konate", "DF");
            player.Rows.Add("britania raya", "Liverpool", "4", "Virgil Van Djik", "DF");
            player.Rows.Add("britania raya", "Liverpool", "2", "Wateru Endo", "MF");
            player.Rows.Add("britania raya", "Liverpool", "6", "Thiago Alcantara", "MF");
            player.Rows.Add("britania raya", "Liverpool", "8", "Dominik Szobozslai", "MF");
            player.Rows.Add("britania raya", "Liverpool", "7", "Luis Diaz", "FW");
            player.Rows.Add("britania raya", "Liverpool", "9", "Darwin Nunez", "FW");
            player.Rows.Add("britania raya", "Liverpool", "11", "Mohamed Salah", "FW");
        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            if (text_TName.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nama Tim");
            }
            else if (text_TCountry.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi negara asal");
            }
            else if (text_TCity.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi asal kota");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < player.Rows.Count; i++)
                {
                    if (text_TName.Text == player.Rows[i][1].ToString())
                    {
                        MessageBox.Show("Nama tim sudah digunakan");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    player.Rows.Add(text_TCountry.Text, text_TName.Text, "", "", "");
                    text_TName.Clear();
                    text_TCountry.Clear();
                    text_TCity.Clear();
                    listPlayer.Items.Clear();
                    cbx_CCountry.Text = string.Empty;
                    cbx_CTeam.Items.Clear();
                    cbx_CTeam.Text = string.Empty;
                    lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;
                }
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            string selectedTeam = cbx_CTeam.SelectedItem?.ToString();
            if (listPlayer.Items.Count <= 11)
            {
                MessageBox.Show("Harus memiliki 11 player untuk menggunakan fitur Remove", "Warning!");

            }
            else if (!string.IsNullOrEmpty(selectedTeam))
            {
                foreach (DataRow row in player.Rows)
                {
                    if (row["Team"].ToString() == selectedTeam && row["No"].ToString() == listPlayer.SelectedItem.ToString().Split(' ')[0].Trim('(', ')'))
                    {
                        row.Delete();
                        break;
                    }
                }
            }

            listPlayer.Items.Remove(listPlayer.SelectedItem);
            lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            if (cbx_CTeam.Text.Length == 0)
            {
                MessageBox.Show("Pilih Tim terlebih dahulu sebelum menambahkan pemain");
            }
            else if (text_PName.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nama pemain");
            }
            else if (text_PNumber.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nomor pemain");
            }
            else if (cbx_PPosition.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi posisi");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < player.Rows.Count; i++)
                {
                    if (text_PName.Text == player.Rows[i][3].ToString() || text_PNumber.Text == player.Rows[i][2].ToString())
                    {
                        MessageBox.Show("Nama atau nomor pemain tidak boleh sama");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    player.Rows.Add(cbx_CCountry.SelectedItem.ToString(), cbx_CTeam.SelectedItem.ToString(), text_PNumber.Text.ToString(), text_PName.Text.ToString(), cbx_PPosition.SelectedItem.ToString());
                    listPlayer.Items.Clear();
                    for (int i = 0; i < player.Rows.Count; i++)
                    {
                        if (player.Rows[i][1] == cbx_CTeam.SelectedItem)
                        {
                            listPlayer.Items.Add("(" + player.Rows[i][2] + ") " + player.Rows[i][3] + ". " + player.Rows[i][4]);
                        }
                    }
                    lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;
                    text_PName.Clear();
                    text_PNumber.Clear();
                    cbx_PPosition.Text = string.Empty;
                }
            }
        }
    

        private void cbx_CCountry_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < player.Rows.Count; i++)
            {
                if (!cbx_CCountry.Items.Contains(player.Rows[i][0]))
                {
                    cbx_CCountry.Items.Add(player.Rows[i][0]);
                }
            }
            lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;
        }

        private void cbx_CCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbx_CTeam.Items.Clear();
            cbx_CTeam.Text = string.Empty;
            listPlayer.Items.Clear();
            lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;

            string selectedCountry = cbx_CCountry.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedCountry))
            {
                foreach (DataRow row in player.Rows)
                {
                    if (row["Negara"].ToString() == selectedCountry)
                    {
                        string teamName = row["Team"].ToString();
                        if (!cbx_CTeam.Items.Contains(teamName))
                        {
                            cbx_CTeam.Items.Add(teamName);
                        }
                    }
                }
            }
        }

        private void cbx_CTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listPlayer.Items.Clear();

            string selectedTeam = cbx_CTeam.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedTeam))
            {
                foreach (DataRow row in player.Rows)
                {
                    if (row["Team"].Equals(selectedTeam))
                    {
                        listPlayer.Items.Add("(" + row["No"] + ") " + row["nama"] + ". " + row["role"]);
                    }
                }
            }

            lbl_JP.Text = "Jumlah Pemain = " + listPlayer.Items.Count;
        }
    }
}