﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace sepak_bola
{
    public partial class Form1 : Form
    {
        DataTable player = new DataTable();
        DataTable team = new DataTable();

        public Form1()
        {
            InitializeComponent();
            datatable();
            FillCountryComboBox();
        }
        private void datatable()
        {
            player.Columns.Add("Nama", typeof(string));
            player.Columns.Add("Nomor_Player", typeof(int));
            player.Columns.Add("Position_Player", typeof(string));
            player.Columns.Add("Negara", typeof(string));
            player.Columns.Add("tim", typeof(string));
            player.Columns.Add("kota", typeof(string));

            team.Columns.Add("Negara", typeof(string));
            team.Columns.Add("NamaTim", typeof(string));

        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            string teamName = text_TName.Text;
            string country = text_TCountry.Text;
            string city = text_TCity.Text;

            // Menambahkan baris baru ke dalam DataTable
            player.Rows.Add("", 0, "", country, teamName, city);

            // Cek apakah negara sudah ada di ComboBox
            if (!cbx_CCountry.Items.Contains(country))
            {
                // Jika tidak, tambahkan negara ke ComboBox
                cbx_CCountry.Items.Add(country);
            }

            // Pilih negara yang baru ditambahkan
            cbx_CCountry.SelectedItem = country;

            // Cek apakah nama tim sudah ada di ComboBox
            if (!cbx_CTeam.Items.Contains(teamName))
            {
                // Jika tidak, tambahkan nama tim ke ComboBox
                cbx_CTeam.Items.Add(teamName);
            }

            // Pilih nama tim yang baru ditambahkan
            cbx_CTeam.SelectedItem = teamName;
            text_TName.Clear();
            text_TCountry.Clear();
            text_TCity.Clear();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            // Mendapatkan indeks item yang dipilih di ListBox
            int selectedIndex = listPlayer.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Menghapus baris yang sesuai dari DataTable berdasarkan indeks item yang dipilih di ListBox
                player.Rows.RemoveAt(selectedIndex);

                // Membersihkan ListBox setelah data dihapus
                listPlayer.Items.RemoveAt(selectedIndex);
            }
            else
            {
                MessageBox.Show("Pilih pemain yang ingin dihapus terlebih dahulu.");
            }
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            string playerName = text_PName.Text;
            string playerPosition = cbx_PPosition.SelectedItem?.ToString();

            // Validasi ComboBox
            if (string.IsNullOrEmpty(playerPosition))
            {
                MessageBox.Show("Pilih posisi pemain terlebih dahulu.");
                return;
            }

            // Validasi nomor pemain
            if (!int.TryParse(text_PNumber.Text, out int playerNumber))
            {
                MessageBox.Show("Nomor pemain harus berupa angka.");
                return;
            }

            // Menambahkan baris baru ke dalam DataTable
            player.Rows.Add(playerName, playerNumber, playerPosition, "", "", "");

            // Menambahkan nama pemain ke dalam ListBox
            listPlayer.Items.Add("[" + playerNumber + "] " + playerName + " " + playerPosition);

            // Membersihkan TextBox setelah data ditambahkan
            text_PName.Clear();
            text_PNumber.Clear();
        }
        private void FillCountryComboBox()
        {
            // Mendapatkan daftar negara unik dari DataTable team
            var countries = team.AsEnumerable().Select(row => row.Field<string>("Negara")).Distinct();

            // Tambahkan daftar negara ke dalam ComboBox negara
            cbx_CCountry.Items.AddRange(countries.ToArray());
        }

        private void cbx_CCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbx_CTeam.Items.Clear();
            for(int i = 0; i < player.Rows.Count; i++)
            {
                if (team.Rows[i][0] == cbx_CCountry.SelectedItem)
                {
                    if (!cbx_CTeam.Items.Contains(player.Rows[i][4]))
                    {
                        cbx_CTeam.Items.Add(team.Rows[i][1]);
                    }
                }
            }
            lbl_JP.Text = "Jumlah Pemain" + listPlayer.Items.Count;
        }

        private void cbx_CTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listPlayer.Items.Clear();
            for (int i = 0; i < player.Rows.Count; i++)
            {
                if (player.Rows[i][3] == cbx_CCountry.SelectedItem)
                {
                    if (!cbx_CTeam.Items.Contains(player.Rows[i][4]))
                    {
                        listPlayer.Items.Add(player.Rows[i][4]);
                    }
                }
            }
           
            lbl_JP.Text = "Jumlah Pemain" + listPlayer.Items.Count;
        }
    }

}