﻿namespace PR_terakhir_appdev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cb_home = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_away = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.date_match = new System.Windows.Forms.DateTimePicker();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Match ID";
            // 
            // cb_home
            // 
            this.cb_home.FormattingEnabled = true;
            this.cb_home.Location = new System.Drawing.Point(142, 117);
            this.cb_home.Name = "cb_home";
            this.cb_home.Size = new System.Drawing.Size(146, 24);
            this.cb_home.TabIndex = 3;
            this.cb_home.SelectedIndexChanged += new System.EventHandler(this.cb_home_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Team Home";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(495, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Match Date";
            // 
            // cb_away
            // 
            this.cb_away.FormattingEnabled = true;
            this.cb_away.Location = new System.Drawing.Point(576, 120);
            this.cb_away.Name = "cb_away";
            this.cb_away.Size = new System.Drawing.Size(146, 24);
            this.cb_away.TabIndex = 9;
            this.cb_away.SelectedIndexChanged += new System.EventHandler(this.cb_away_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(491, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Team Away";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(142, 89);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(146, 22);
            this.tb_id.TabIndex = 10;
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(55, 184);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(544, 225);
            this.dgv.TabIndex = 11;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(676, 223);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(176, 24);
            this.cb_team.TabIndex = 15;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(627, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Team";
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(676, 283);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(176, 24);
            this.cb_type.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(631, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 16);
            this.label7.TabIndex = 18;
            this.label7.Text = "Type";
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(676, 253);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(176, 24);
            this.cb_player.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(624, 256);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 16);
            this.label8.TabIndex = 16;
            this.label8.Text = "Player";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(676, 195);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(176, 22);
            this.tb_minute.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(624, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "Minute";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(676, 313);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(85, 31);
            this.btn_add.TabIndex = 22;
            this.btn_add.Text = "add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(767, 313);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(85, 31);
            this.btn_delete.TabIndex = 23;
            this.btn_delete.Text = "delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // date_match
            // 
            this.date_match.Location = new System.Drawing.Point(576, 93);
            this.date_match.Name = "date_match";
            this.date_match.Size = new System.Drawing.Size(243, 22);
            this.date_match.TabIndex = 24;
            this.date_match.ValueChanged += new System.EventHandler(this.date_match_ValueChanged);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(248, 428);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(85, 31);
            this.btn_insert.TabIndex = 25;
            this.btn_insert.Text = "insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 554);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.date_match);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.cb_away);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cb_home);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_home;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_away;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.DateTimePicker date_match;
        private System.Windows.Forms.Button btn_insert;
    }
}

