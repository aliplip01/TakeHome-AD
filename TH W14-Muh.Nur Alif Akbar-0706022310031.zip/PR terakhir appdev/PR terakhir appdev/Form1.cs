﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PR_terakhir_appdev
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlQuery;
        DataTable dtTeams;
        DataTable dtPlayers;
        DataTable dtMatchDetails;
        DataTable dtDate;
        public Form1()
        {
            InitializeComponent();

            sqlConnection = new MySqlConnection("server=localhost; user=root; pwd=Alifakmal288; database=premier_league;");

            LoadTeams();
            InitializeDataGridView();
            InitializeComboBoxes();
        }
        private void LoadTeams()
        {
            dtTeams = new DataTable();
            sqlConnection.Open();
            sqlQuery = "SELECT team_name FROM team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeams);
            sqlConnection.Close();

            cb_home.DataSource = dtTeams.Copy();
            cb_home.DisplayMember = "team_name";
            cb_home.SelectedIndex = -1;

            cb_away.DataSource = dtTeams.Copy();
            cb_away.DisplayMember = "team_name";
            cb_away.SelectedIndex = -1;
        }
        private void InitializeDataGridView()
        {
            dtMatchDetails = new DataTable();
            dtMatchDetails.Columns.Add("Minute");
            dtMatchDetails.Columns.Add("Team");
            dtMatchDetails.Columns.Add("Player");
            dtMatchDetails.Columns.Add("Type");
            dtMatchDetails.Columns.Add("Team_ID");

            dgv.DataSource = dtMatchDetails;
        }
        private void InitializeComboBoxes()
        {
            cb_type.Items.AddRange(new string[] { "GO", "GP", "GW", "CR", "CY", "PM" });
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tb_minute.Text) && cb_team.SelectedIndex != -1 && cb_player.SelectedIndex != -1 && cb_type.SelectedIndex != -1)
            {
                dtMatchDetails.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
            }
            else
            {
                MessageBox.Show("Please fill in all fields before adding.");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv.CurrentRow != null)
            {
                dtMatchDetails.Rows.RemoveAt(dgv.CurrentRow.Index);
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            foreach (DataRow row in dtMatchDetails.Rows)
            {
                try
                {
                    DataTable dtTeamId = GetTeamId(row["Team"].ToString());
                    DataTable dtPlayerId = GetPlayerId(row["Player"].ToString());

                    if (dtTeamId.Rows.Count > 0 && dtPlayerId.Rows.Count > 0)
                    {
                        string insertQuery = $"INSERT INTO dmatch VALUES('{tb_id.Text}', '{row["Minute"]}', '{dtTeamId.Rows[0]["team_id"]}', '{dtPlayerId.Rows[0]["player_id"]}', '{row["Type"]}', '0');";
                        ExecuteNonQuery(insertQuery);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private DataTable GetTeamId(string teamName)
        {
            DataTable dtTeamId = new DataTable();
            string query = $"SELECT team_id FROM team WHERE team_name = '{teamName}'";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamId);
            return dtTeamId;
        }
        private DataTable GetPlayerId(string playerName)
        {
            DataTable dtPlayerId = new DataTable();
            string query = $"SELECT player_id FROM player WHERE player_name = '{playerName}'";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayerId);
            return dtPlayerId;
        }
        private void ExecuteNonQuery(string query)
        {
            sqlConnection.Open();
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTeamComboBox();
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTeamComboBox();
        }
        private void UpdateTeamComboBox()
        {
            cb_team.Items.Clear();
            if (cb_home.SelectedIndex != -1 && cb_away.SelectedIndex != -1 && cb_home.Text != cb_away.Text)
            {
                cb_team.Items.Add(cb_home.Text);
                cb_team.Items.Add(cb_away.Text);
            }
            else
            {
                MessageBox.Show("Please select two different teams.");
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_team.SelectedIndex != -1)
            {
                LoadPlayers(cb_team.Text);
            }
        }
        private void LoadPlayers(string teamName)
        {
            dtPlayers = new DataTable();
            sqlQuery = $"SELECT player_name FROM player WHERE team_id = (SELECT team_id FROM team WHERE team_name = '{teamName}')";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayers);

            cb_player.DataSource = dtPlayers;
            cb_player.DisplayMember = "player_name";
            cb_player.SelectedIndex = -1;
        }

        private void date_match_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                dtDate = new DataTable();
                string year = date_match.Value.Year.ToString();
                tb_id.Text = year;
                sqlQuery = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{year}%'";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtDate);

                int matchCount = Convert.ToInt32(dtDate.Rows[0][0]) + 1;
                tb_id.Text = $"{year}{matchCount:D3}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
